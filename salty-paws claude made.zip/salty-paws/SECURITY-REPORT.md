# Salty Paws: security testing report

Date: 21 November 2026. Everything below was run in a build sandbox with **no internet and no Postgres**. Nothing was tested against a real Supabase project, real Netlify deployment, real Cloudflare Turnstile or real email delivery. Section 4 lists what that leaves unverified.

## 1. What was tested (and how)

| Suite | Count | What it does |
|---|---|---|
| `tests/pricing`, `tests/validate` | 20 | Pricing table, holiday surcharge, Australian phone/email/date rules, enums, length limits, unexpected fields, wrong types, prototype-key payloads, control/bidi character stripping |
| `tests/public-endpoints` | 22 | Real function code against a fake network: valid/multi-pet/no-email enquiries, tampering (price/status/ids), duplicate submission, DB failure and network failure (no leaks), email failure, honeypot, Turnstile failure, rate limiting (and fail-closed), oversize/malformed/wrong-type bodies, cross-origin, injection payloads, review consent/rating/status tampering, public reviews use anon key + safe columns only, config endpoint leaks no secrets |
| `tests/admin` | 12 | Every admin route 401 without login, forged/expired token, valid user who is not an admin, user-token (not service key) used for admin reads, CSRF (origin + header), id/status/filter injection attempts, cookie flags, generic login failure, login rate limit, logout |
| `tests/static` | 12 | No secrets/JWTs/Supabase URLs in browser files; service key referenced in one module only; no inline scripts/styles/handlers (CSP-safe); no `innerHTML`/`eval`; HTML prices equal config; strict CSP in `netlify.toml`; SQL: RLS on all 6 tables, only one `anon` grant, no `using (true)`, no grants to PUBLIC, every `security definer` pins `search_path`; no dependencies |
| `tests/e2e/browser_test.py` | 51 | Real Chromium (desktop + 390px mobile emulation) with the production CSP: forms, double-submit, validation messages, estimate, pending reviews hidden then approved, XSS payloads in name/pet/notes/reviews render as inert text on the public page and in the dashboard, login/logout, cookie flags (HttpOnly, SameSite=Strict, unreadable by JS), status/filter/delete, rate limit, no CSP violations, no browser traffic to Supabase, no horizontal scroll |

## 2. What passed

All of the above: **66/66 Node tests and 51/51 browser checks** on the final code.

## 3. What failed during development (all fixed)

* A CSS class clash made admin button labels grey on coloured buttons (low contrast). Found by looking at a screenshot; fixed and a regression check added.
* A brace-expansion mistake created no folders at first; fixed.
* Several failures were bugs in my tests (restore order of the fake network, an undersized "oversized" payload, a false-positive SQL grep). The application code was not at fault; the tests were corrected.
* No application security test failed. That is not proof of security; see section 4.

## 4. What remains UNVERIFIED

1. **The RLS policies on a real Postgres.** The SQL was never executed. `supabase/tests/rls_tests.sql` exists to check it; it has also never been run. Possible surprises: syntax errors, or column-level grant + RLS interplay for `anon` on `reviews`. **Run it (README step 4).**
2. **Supabase API behaviour:** PostgREST embeds (`customers(...)`, `pets(...)`), `Prefer` headers, and calls using the **new `sb_publishable_` / `sb_secret_` keys** (the code sends them as `apikey` only; legacy JWT keys are also sent as bearer). Login/refresh/logout against real Supabase Auth.
3. **Real Turnstile with the CSP.** Tests used a stub script served from the allowed host. If the live widget is blocked, check the console and widen CSP only for `challenges.cloudflare.com`.
4. **Netlify specifics:** headers actually applied, `/api/*` function routing, `context.ip`, scheduled function, Secure cookies in production, function region (may process data outside Australia).
5. **Email** via Resend (never sent).
6. **Real devices/browsers:** only Chromium with mobile emulation. Not tested on Safari, Firefox or real phones.
7. **No MFA** on the admin login, no external penetration test, no load test.
8. The privacy notice is a **draft**, not legal advice. I have not claimed compliance with the Privacy Act/APPs.

## 5. Actions YOU must take before going live

1. Run the migrations, then `rls_tests.sql`; confirm every line is PASS (README steps 3-4).
2. In Supabase: sign-ups OFF; Sydney region; strong unique admin password (use a password manager).
3. Set all Netlify environment variables; secrets scoped to Functions/Runtime; confirm no secret is in the Git repo.
4. On the **deployed** site, from your phone: send an enquiry (check it arrives in `/admin/` and the email alert), submit and approve a review, sign out and confirm `/admin/` shows only the login.
5. Check headers at securityheaders.com and the browser console for CSP errors on the live site.
6. Try to break it: open the live site's `/api/admin/enquiries` while logged out (must be 401) and visit `https://YOUR-PROJECT.supabase.co/rest/v1/customers?select=*` with only the public key (must be denied).
7. Review and edit `public/privacy.html`; confirm 24-month retention is something you will actually do (set up the cron in README).
8. Decide on Supabase plan: free projects pause after ~7 days of low activity (mitigated by `keepalive`, not guaranteed) and have limited backups.
9. Update `src/config/holidays.mjs` each year.

## 6. Design decisions and assumptions to be aware of

* Existing site source wasn't available, so the frontend was **rebuilt from the live page's text**; colours/typography are new. Content, prices and contact details were kept.
* Repeat customers are matched by phone number; existing name/email are never overwritten by public input (so a shared number keeps the first name). The enquiry notes carry any difference.
* Rate limits: enquiries 8 per 15 min per IP; reviews 3 per hour; admin login 10 per 15 min. IPs are stored only as keyed hashes and purged after a day.
* The admin cookie lasts up to 1 hour, refreshed for up to 7 days of continued use.
* Estimates are indicative only, never shown as quotes or confirmed prices.
