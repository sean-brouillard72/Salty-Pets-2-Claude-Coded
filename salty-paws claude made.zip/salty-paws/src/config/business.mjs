// Central business rules. Edit prices/labels HERE (amounts are in cents).
export const PRICES = {
  dog_walk_30: 2000,
  dog_walk_60: 3500,
  dog_walk_extra_dog: 500,
  home_visit: 2000,
  home_visit_extra_dog: 500,
  boarding_night: 3500,
  boarding_extra_dog_night: 1000,
  overnight_night: 4500,
};
export const HOLIDAY_SURCHARGE = 0.2; // 20% on public holidays

export const SERVICES = {
  meet_and_greet: 'Free meet and greet',
  dog_walk_30: 'Dog walk (30 minutes)',
  dog_walk_60: 'Dog walk (1 hour)',
  home_visit: 'Home visits',
  boarding: 'Boarding at my property',
  overnight: 'Overnight in their home',
  not_sure: 'Not sure yet',
};
export const PET_TYPES = ['dog', 'cat', 'bird', 'rabbit', 'guinea_pig', 'fish', 'reptile', 'other'];
export const PREFERRED_TIMES = ['flexible', 'early_morning', 'morning', 'midday', 'afternoon', 'evening'];
export const FREQUENCIES = ['one_off', 'weekly', 'several_weekly', 'not_sure'];
export const STATUSES = ['new', 'contacted', 'awaiting_response', 'accepted', 'declined', 'completed'];
export const REVIEW_STATUSES = ['pending', 'approved', 'rejected'];

export const LIMITS = {
  maxPets: 8,
  maxBodyBytes: 20 * 1024,
  maxStayDays: 90,
  maxAdvanceDays: 548,
};
