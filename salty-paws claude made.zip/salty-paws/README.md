# Salty Paws website

Static website + Netlify Functions + Supabase (Postgres and Auth). No npm dependencies, no build step, no payments.

```
public/                 the website (index, privacy, 404, admin/ dashboard)
netlify/functions/      server code: enquiry, review, reviews, config, admin, keepalive
src/config/             BUSINESS RULES: prices (business.mjs), WA public holidays (holidays.mjs)
src/lib/                validation, pricing, Supabase client, Turnstile, rate limit, email, logging
supabase/migrations/    0001 schema, 0002 RLS + privileges, 0003 server-only functions
supabase/tests/         rls_tests.sql  (run once in the Supabase SQL editor)
tests/                  unit/endpoint/static tests (npm test) + tests/e2e browser test
netlify.toml            publish dir, redirects, security headers (CSP etc.)
.env.example            names of the environment variables (placeholders only)
SECURITY-REPORT.md      what was tested, what passed, what is unverified, what YOU must do
```

## How it works (short version)

* The browser only ever talks to **your own site** (`/api/...`). It never talks to Supabase and holds no keys.
* **Enquiries and reviews** go to Netlify Functions, which check: same origin, size limit, honeypot, rate limit, strict validation (unknown fields rejected), Cloudflare Turnstile, then save through a database function. Prices are calculated **on the server**; the browser cannot send a price.
* **The database denies everything by default** (Row Level Security). The public can read only *approved* reviews and only their safe columns. Customers, enquiries and pets are unreadable without admin login.
* **Admin login** goes through `/api/admin/login` (Supabase Auth). The session lives in an HttpOnly, Secure, SameSite=Strict cookie that JavaScript cannot read. Dashboard actions run **as you** under RLS; the database checks you are in the `admins` table on every query. The service-role key is never used for dashboard actions.
* **Enquiries are never "confirmed bookings".** The confirmation says so and shows an indicative estimate only.

## Changing business rules

| What | Where |
|---|---|
| Prices, surcharge %, service names | `src/config/business.mjs` (cents). The page text updates automatically; `npm test` fails if the HTML fallback numbers drift. |
| Public holidays | `src/config/holidays.mjs`. **Update every year** from wa.gov.au (2026–2029 filled in; Show Day from 2028 isn't proclaimed yet). |
| Estimate rules | `src/lib/pricing.mjs` |

Estimate assumptions: only one-off bookings can be estimated (recurring/unclear → no estimate). Boarding and overnight are priced per night, and a night counts on the date it **starts**. The 20% surcharge applies to each day/night that falls on a public holiday. Extra-dog charges apply to dogs only.

## Environment variables (Netlify > Site configuration > Environment variables)

Mark the secret ones **"Contains secret values"** and scope them to **Functions** and **Runtime** only.

| Variable | Secret? | What it does |
|---|---|---|
| `SUPABASE_URL` | no | Your project URL, e.g. `https://abcd1234.supabase.co`. |
| `SUPABASE_ANON_KEY` | no (public key) | Supabase **publishable** (or legacy `anon`) key. Used by functions for public reads and admin login; always subject to RLS. |
| `SUPABASE_SERVICE_ROLE_KEY` | **YES** | Supabase **secret** (or legacy `service_role`) key. Bypasses RLS. Used only to save enquiries/reviews and for rate limiting. Never put it in the browser or Git. |
| `TURNSTILE_SITE_KEY` | no | Cloudflare Turnstile site key (shown to the browser via `/api/config`). |
| `TURNSTILE_SECRET_KEY` | **YES** | Turnstile secret, used server-side to verify the check. |
| `IP_HASH_SECRET` | **YES** | Random 32+ character string (`openssl rand -hex 32`). Used to hash IP addresses so raw IPs are never stored. |
| `RESEND_API_KEY` | **YES** | Optional. Email alerts for new enquiries. |
| `NOTIFY_EMAIL_TO` | no | Optional. Where alerts go. With Resend's default sender this must be the email you signed up to Resend with. |
| `NOTIFY_EMAIL_FROM` | no | Optional. Only after verifying your own domain in Resend, e.g. `Salty Paws <alerts@yourdomain.com.au>`. |
| `SITE_URL` | no | Optional. Add your custom domain(s), comma-separated, e.g. `https://www.saltypaws.com.au`. Netlify's own URL is allowed automatically. |

## Deployment, step by step

Button labels in Supabase/Netlify/Cloudflare change from time to time; look for the closest match.

**1. Put the project in a private Git repository** (GitHub/GitLab). Check that no `.env` file is included (`.gitignore` already blocks it).

**2. Create the Supabase project**
1. supabase.com > New project. Choose region **Sydney (ap-southeast-2)** so data stays in Australia, and a long random database password (save it in a password manager).
2. Authentication > Sign In / Providers: **turn OFF "Allow new users to sign up"**. (Even if left on, strangers can't see anything because they aren't in the `admins` table, but turn it off.)
3. Project Settings > API Keys: copy the URL, the publishable/anon key and the secret/service_role key. Keep them for step 6.

**3. Apply the database migrations.** SQL Editor > New query. Paste and run, **in order**: `supabase/migrations/0001_schema.sql`, `0002_rls.sql`, `0003_functions.sql`. (Or use the Supabase CLI.)

**4. Run the security test.** Paste `supabase/tests/rls_tests.sql` and run it. Open the Messages/Notices output. **Every line must start with PASS.** Any FAIL means stop and ask for help. It rolls back and leaves no data.

**5. Create your admin account**
1. Authentication > Users > Add user > Create new user. Your email, a **long unique password**, tick *Auto Confirm User*.
2. SQL Editor, run (with your email): 
   `insert into public.admins (user_id) select id from auth.users where email = 'you@example.com';`

**6. Third-party services**
* **Cloudflare Turnstile** (free): dash.cloudflare.com > Turnstile > Add widget. Add your Netlify hostname (and custom domain later). Copy the site key and secret key. (For testing only, Cloudflare publishes always-pass test keys in its docs. Never use them live.)
* **Resend** (optional, free tier): resend.com, sign up with the email address you want alerts sent to, create an API key. With the default sender (`onboarding@resend.dev`) Resend only delivers to your own account email, which is fine for owner alerts. No domain needed.

**7. Netlify**
1. Add new site > Import from Git > pick the repo. Settings are read from `netlify.toml` (publish `public`, functions `netlify/functions`, no build command).
2. **Before deploying**, add all environment variables from the table above.
3. Deploy. Optionally add your custom domain, then add it to `SITE_URL` and to the Turnstile widget hostnames.

**8. Test the live site** (not skipped, see `SECURITY-REPORT.md` section 5):
send a test enquiry from your phone, check it appears in `/admin/`, approve a test review, check security headers at securityheaders.com, and look at the browser console for blocked-by-CSP errors.

**9. Before real customers:** read the privacy notice (`public/privacy.html`), fix anything that isn't true for your business, and ideally have a privacy adviser check it. Supabase **free projects are paused after ~7 days of low activity**; `keepalive.mjs` pings the database 3x a day to prevent this, but it is a mitigation, not a guarantee. The paid plan removes pausing and adds backups; that is your call (see report).

## Day-to-day

* **Dashboard:** `https://your-site/admin/`. Enquiries: filter by status, change status, delete enquiry, or *Delete customer and all data* (privacy requests). Reviews: approve/reject; only approved reviews appear publicly.
* **Retention:** the privacy notice promises declined/completed enquiries are deleted after 24 months. Automate it: Database > Extensions > enable `pg_cron`, then run
  `select cron.schedule('purge-old-enquiries', '0 3 * * 0', $$select public.purge_old_enquiries(24)$$);`
  or run `select public.purge_old_enquiries(24);` yourself every few months.
* **Lost password / rotating keys:** reset the user in Supabase Authentication; rotate keys in Supabase, then update Netlify variables and redeploy.
* **Logs:** Netlify > Logs > Functions. Events like `rate_limited`, `captcha_failed`, `honeypot`, `login_failed` contain no personal information (only a hashed IP fragment).

## Running the tests locally

```
npm test                       # 66 unit/endpoint/static tests (Node 20+, no installs)
tests/e2e/run.sh               # Chromium end-to-end test (needs python3 + playwright)
```
The e2e harness serves the site with the real `netlify.toml` headers against an in-memory fake of Supabase. It does not replace testing the deployed site.
