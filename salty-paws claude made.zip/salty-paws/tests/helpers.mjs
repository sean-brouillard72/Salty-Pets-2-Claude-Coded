import { addDays, perthToday } from '../src/lib/dates.mjs';

export const ENV = {
  SUPABASE_URL: 'https://proj.supabase.co',
  SUPABASE_ANON_KEY: 'anon-test-key',
  SUPABASE_SERVICE_ROLE_KEY: 'service-test-key-SECRET-VALUE',
  TURNSTILE_SECRET_KEY: 'ts-secret',
  IP_HASH_SECRET: 'x'.repeat(32),
  RESEND_API_KEY: 're_test',
  NOTIFY_EMAIL_TO: 'owner@example.com',
};
export function setEnv() { Object.assign(process.env, ENV); delete process.env.SITE_URL; delete process.env.URL; delete process.env.DEPLOY_PRIME_URL; }

export const ORIGIN = 'https://salty.example';
export const future = (n) => addDays(perthToday(), n);

export function req(path, { method = 'POST', body, headers = {}, origin = ORIGIN, raw } = {}) {
  const h = { 'content-type': 'application/json', ...(origin ? { origin } : {}), ...headers };
  return new Request(ORIGIN + path, { method, headers: h, body: method === 'GET' ? undefined : (raw ?? JSON.stringify(body)) });
}

export const goodEnquiry = (over = {}) => ({
  submission_id: crypto.randomUUID(), turnstile_token: 'tok', website: '',
  name: 'Jane Citizen', phone: '0412 345 678', email: 'jane@example.com',
  pets: [{ type: 'dog', name: 'Rex', breed: 'Kelpie', age: '3', notes: 'Loves the beach' }],
  service: 'dog_walk_30', start_date: future(10), end_date: '', preferred_time: 'morning',
  visits_per_day: '1', frequency: 'one_off', specific_times: '', notes: '', ...over,
});

// Programmable fake network. handler(url, init, calls) => Response | object | undefined
export function mockFetch(handler) {
  const calls = [];
  const orig = globalThis.fetch;
  globalThis.fetch = async (url, init = {}) => {
    const call = { url: String(url), method: init.method || 'GET', headers: init.headers || {}, body: init.body ? safeJson(init.body) : undefined };
    calls.push(call);
    const out = await handler(call, calls);
    if (out instanceof Response) return out;
    if (out === undefined) return new Response('{}', { status: 200 });
    return new Response(JSON.stringify(out.body ?? null), { status: out.status ?? 200 });
  };
  return { calls, restore() { globalThis.fetch = orig; } };
}
function safeJson(b) { try { return JSON.parse(b); } catch { return String(b); } }

// Default happy-path network for public endpoints.
export const happyNet = (over = {}) => (c) => {
  if (over[c.url]) return over[c.url](c);
  if (c.url.includes('/rpc/rate_limit_hit')) return { body: true };
  if (c.url.includes('/rpc/submit_enquiry')) return { body: { reference: 'SP-TEST1234', duplicate: false } };
  if (c.url.includes('turnstile')) return { body: { success: true } };
  if (c.url.includes('api.resend.com')) return { body: { id: 'x' } };
  if (c.url.includes('/rest/v1/reviews')) return { status: 201, body: null };
  return { status: 404, body: null };
};
