"""End-to-end browser test (Chromium) against tests/e2e/server.mjs. Run: python3 tests/e2e/browser_test.py"""
import json, sys, urllib.request, os
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8899"
results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail)); print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if (detail and not ok) else ""))
def db(): return json.load(urllib.request.urlopen(BASE + "/__db"))
def reset(): urllib.request.urlopen(BASE + "/__reset").read()

STUB = "window.turnstile={_n:0,render:function(s,o){var id='w'+(window.turnstile._n++);window.turnstile['_'+id]='TOKEN-'+id;return id},getResponse:function(id){return window.turnstile['_'+id]||''},reset:function(){}};"
XSS = '<img src=x onerror="window.__xss=1">'
os.makedirs("/tmp/shots", exist_ok=True)

def attach(page, bag):
    page.on("console", lambda m: bag["console"].append((m.type, m.text)))
    page.on("pageerror", lambda e: bag["errors"].append(str(e)))
    page.on("request", lambda r: bag["urls"].append(r.url))
    page.route("https://challenges.cloudflare.com/turnstile/v0/api.js*", lambda r: r.fulfill(content_type="text/javascript", body=STUB))

def fill_enquiry(page, phone="0412 345 678", name="Jane Citizen", pet2=True, notes="", pet_name="Rex"):
    f = "#enquiry-form "
    page.fill(f + "[name=name]", name); page.fill(f + "[name=phone]", phone)
    pets = page.locator("#pets .pet")
    pets.nth(0).locator("[data-f=type]").select_option("dog"); pets.nth(0).locator("[data-f=name]").fill(pet_name)
    pets.nth(0).locator("[data-f=breed]").fill("Kelpie")
    if pet2:
        if pets.count() < 2: page.click("#add-pet")
        pets = page.locator("#pets .pet")
        pets.nth(1).locator("[data-f=type]").select_option("dog"); pets.nth(1).locator("[data-f=name]").fill("Bo")
    page.select_option(f + "[name=service]", "dog_walk_60")
    page.fill(f + "[name=start_date]", "2026-12-24"); page.fill(f + "[name=end_date]", "2026-12-26")
    page.select_option(f + "[name=visits_per_day]", "2"); page.select_option(f + "[name=frequency]", "one_off")
    if notes: page.fill(f + "[name=notes]", notes)

with sync_playwright() as p:
    browser = p.chromium.launch()
    reset()
    ctx = browser.new_context(viewport={"width": 1280, "height": 900})
    page = ctx.new_page(); bag = {"console": [], "errors": [], "urls": []}; attach(page, bag)

    # ---------- page load, CSP, no third-party / Supabase traffic ----------
    resp = page.goto(BASE + "/"); page.wait_for_load_state("networkidle")
    check("home page loads with CSP header", "default-src 'self'" in resp.headers.get("content-security-policy", ""))
    check("no CSP violations or JS errors on home", not [m for m in bag["console"] if "Content Security Policy" in m[1] or m[0] == "error"] and not bag["errors"], str(bag["console"] + bag["errors"]))
    check("prices rendered from server config", page.inner_text("[data-price=dog_walk_60]") == "35" and page.inner_text("[data-surcharge]") == "20")
    check("turnstile widgets rendered via allowed script host", "TOKEN-w0" in page.evaluate("turnstile.getResponse('w0')"))
    check("browser never talks to Supabase directly", not [u for u in bag["urls"] if "supabase" in u])
    hp = page.locator("#enquiry-form .hp input").bounding_box()
    check("honeypot field is off-screen and not tabbable", hp["x"] < 0 and page.get_attribute("#enquiry-form .hp input", "tabindex") == "-1")
    page.screenshot(path="/tmp/shots/home_desktop.png", full_page=True)

    # ---------- enquiry: validation message from the server ----------
    fill_enquiry(page, phone="123")
    page.click("#enquiry-submit"); page.wait_for_selector("#enquiry-status.err")
    check("bad phone: server validation message shown, nothing stored", "valid Australian phone" in page.inner_text("#enquiry-status") and len(db()["enquiries"]) == 0)

    # ---------- enquiry: success, multiple pets, estimate, double-submit guard ----------
    page.fill("#enquiry-form [name=phone]", "0412 345 678")
    page.evaluate("const f=document.querySelector('#enquiry-form'); f.requestSubmit(); f.requestSubmit();")
    page.wait_for_selector("#enquiry-done:not([hidden])")
    d = db()
    check("enquiry stored once despite double submit", len(d["enquiries"]) == 1 and len(d["customers"]) == 1, str(len(d["enquiries"])))
    check("two pets saved against the enquiry", len(d["enquiries"][0]["pets"]) == 2)
    check("phone normalised to E.164", d["customers"][0]["phone_e164"] == "+61412345678")
    ref = page.inner_text("#done-ref"); est = page.inner_text("#done-estimate")
    check("confirmation shows reference and says NOT a confirmed booking", ref.startswith("SP-") and "not a confirmed booking" in page.inner_text("#enquiry-done"))
    check("server estimate $272 (2 dogs x 1h x 2/day x 3 days + 20% on 2 holidays)", "$272" in est and "public holiday" in est, est)
    page.screenshot(path="/tmp/shots/enquiry_done.png")
    page.click("#again")
    check("form resets for another enquiry", page.is_visible("#enquiry-form") and page.locator("#pets .pet").count() == 1 and page.input_value("#enquiry-form [name=name]") == "")

    # XSS-laden enquiry (for the dashboard test)
    fill_enquiry(page, phone="0498 765 432", name=XSS, pet2=False, notes=XSS, pet_name=XSS)
    page.click("#enquiry-submit"); page.wait_for_selector("#enquiry-done:not([hidden])")
    check("XSS enquiry accepted as plain data", len(db()["enquiries"]) == 2)
    check("no script executed on the public page", page.evaluate("window.__xss") is None)

    # ---------- reviews: pending until approved ----------
    def leave_review(content, name="Sam"):
        page.goto(BASE + "/#reviews"); page.wait_for_load_state("networkidle")
        page.fill("#review-form [name=name]", name); page.fill("#review-form [name=pet_name]", "Rex")
        page.fill("#review-form [name=content]", content); page.check("#review-form [name=consent]")
        page.click("#review-form button[type=submit]"); page.wait_for_selector("#review-status.ok")
    leave_review("Fantastic service, Rex loved it!")
    leave_review(XSS + " great", name=XSS)
    page.goto(BASE + "/"); page.wait_for_load_state("networkidle")
    check("pending reviews are NOT shown publicly", page.locator("#review-list .review").count() == 0 and page.is_visible("#review-empty"))
    check("reviews saved as pending", [r["status"] for r in db()["reviews"]] == ["pending", "pending"])
    page.fill("#review-form [name=name]", "X"); page.fill("#review-form [name=content]", "long enough review"); page.check("#review-form [name=consent]")
    page.uncheck("#review-form [name=consent]"); page.click("#review-form button[type=submit]")
    check("review requires explicit consent (browser blocks submit)", len(db()["reviews"]) == 2)

    # ---------- admin: locked until login ----------
    page.goto(BASE + "/admin"); page.wait_for_load_state("networkidle")
    check("/admin redirects to /admin/ and shows only the login form", page.url.endswith("/admin/") and page.is_visible("#login") and not page.is_visible("#app"))
    check("no customer data in the unauthenticated dashboard page", "Jane" not in page.content() and "0412" not in page.content())
    api = ctx.request
    r = api.get(BASE + "/api/admin/enquiries"); check("API: enquiries without login -> 401", r.status == 401)
    r = api.post(BASE + "/api/admin/logout", headers={"Origin": "https://evil.example", "X-Requested-With": "salty-paws"}, data="{}")
    check("API: cross-origin admin POST refused", r.status == 403)
    page.fill("#login-form [name=email]", "owner@example.com"); page.fill("#login-form [name=password]", "wrong")
    page.click("#login-form button[type=submit]"); page.wait_for_selector("#login-status.err")
    check("wrong password rejected with generic message", "didn’t work" in page.inner_text("#login-status") and not page.is_visible("#app"))
    page.fill("#login-form [name=password]", "correct horse"); page.click("#login-form button[type=submit]"); page.wait_for_selector("#app:not([hidden])")
    ck = {c["name"]: c for c in ctx.cookies()}
    check("session cookies are HttpOnly + SameSite=Strict, scoped to /api/admin", ck["sp_at"]["httpOnly"] and ck["sp_at"]["sameSite"] == "Strict" and ck["sp_at"]["path"] == "/api/admin")
    check("JavaScript cannot read the session cookie", "sp_at" not in page.evaluate("document.cookie"))
    page.wait_for_selector("#enquiry-list .item")
    check("dashboard lists both enquiries", page.locator("#enquiry-list .item").count() == 2)

    # XSS rendering in the dashboard
    items = page.locator("#enquiry-list .item")
    for i in range(items.count()): items.nth(i).locator("summary").click()
    body = page.inner_text("#enquiry-list")
    check("XSS strings show as literal text in the dashboard", XSS in body)
    check("no script executed in the dashboard; no injected <img> elements", page.evaluate("window.__xss") is None and page.locator("#enquiry-list img").count() == 0)
    check("admin buttons have white text on coloured backgrounds (contrast)", page.evaluate("[...document.querySelectorAll('#enquiry-list .btn:not(.ghost)')].every(b => getComputedStyle(b).color === 'rgb(255, 255, 255)')"))
    page.screenshot(path="/tmp/shots/admin_enquiries.png", full_page=True)

    # status filter, update, delete
    jane = page.locator("#enquiry-list .item", has_text="Jane Citizen")
    check("pets, phone link and estimate visible for Jane", "Bo" in jane.inner_text() and "$272.00" in jane.inner_text() and jane.locator("a[href='tel:+61412345678']").count() == 1)
    jane.locator("select").select_option("accepted"); jane.get_by_text("Save status").click(); page.wait_for_selector("#app-status.ok")
    check("status update persisted", [e["status"] for e in db()["enquiries"]].count("accepted") == 1)
    page.select_option("#enquiry-filter", "accepted"); page.wait_for_timeout(400)
    check("filter by status works", page.locator("#enquiry-list .item").count() == 1)
    page.on("dialog", lambda dlg: dlg.accept())
    page.locator("#enquiry-list .item").first.locator("summary").click()
    page.locator("#enquiry-list .item").first.get_by_text("Delete enquiry", exact=True).click(); page.wait_for_timeout(500)
    check("delete enquiry works", len(db()["enquiries"]) == 1)
    page.select_option("#enquiry-filter", ""); page.wait_for_timeout(400)
    page.locator("#enquiry-list .item").first.locator("summary").click()
    page.locator("#enquiry-list .item").first.get_by_text("Delete customer and all data").click(); page.wait_for_timeout(500)
    check("delete customer removes their data", len(db()["enquiries"]) == 0 and len(db()["customers"]) == 0)

    # review moderation
    page.click("#tab-reviews"); page.wait_for_selector("#review-list .item")
    check("pending reviews listed for moderation", page.locator("#review-list .item").count() == 2)
    page.locator("#review-list .item", has_text="Fantastic").get_by_text("Approve").click(); page.wait_for_timeout(400)
    page.locator("#review-list .item", has_text="great").get_by_text("Approve").click(); page.wait_for_timeout(400)
    check("approve works", sorted(r["status"] for r in db()["reviews"]) == ["approved", "approved"])
    page.select_option("#review-filter", "approved"); page.wait_for_timeout(400)
    page.locator("#review-list .item", has_text="Fantastic").get_by_text("Reject").click(); page.wait_for_timeout(400)
    check("reject works", sorted(r["status"] for r in db()["reviews"]) == ["approved", "rejected"])
    check("no script executed while moderating", page.evaluate("window.__xss") is None)

    # logout invalidates the session
    page.click("#logout"); page.wait_for_selector("#login:not([hidden])")
    r = ctx.request.get(BASE + "/api/admin/enquiries")
    check("logout: cookies cleared and API refuses further requests", r.status == 401 and not [c for c in ctx.cookies() if c["name"] == "sp_at" and c["value"]])

    # public site after moderation
    page.goto(BASE + "/"); page.wait_for_load_state("networkidle")
    check("only approved reviews are public (1 shown)", page.locator("#review-list .review").count() == 1 and not page.is_visible("#review-empty"))
    check("approved XSS review rendered as inert text", page.evaluate("window.__xss") is None and page.locator("#review-list img").count() == 0 and XSS in page.inner_text("#review-list"))
    check("no CSP violations or JS errors across the whole session", not [m for m in bag["console"] if "Content Security Policy" in m[1] or "Refused" in m[1]] and not bag["errors"], str(bag["console"] + bag["errors"]))
    check("no request ever went to Supabase from the browser", not [u for u in bag["urls"] if "supabase" in u])

    # ---------- rate limiting ----------
    reset()
    codes = page.evaluate("""async () => { const out=[]; for (let i=0;i<10;i++){ const r=await fetch('/api/enquiry',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}); out.push(r.status);} return out; }""")
    check("rate limit: first 8 handled, then 429", codes[:8] == [400] * 8 and codes[8:] == [429, 429], str(codes))
    ctx.close()

    # ---------- mobile ----------
    mctx = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    reset(); m = mctx.new_page(); mbag = {"console": [], "errors": [], "urls": []}; attach(m, mbag)
    for path in ["/", "/privacy", "/admin/", "/nope"]:
        m.goto(BASE + path); m.wait_for_load_state("networkidle")
        check(f"mobile {path}: no horizontal scroll", m.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), str(m.evaluate("document.documentElement.scrollWidth")))
    m.goto(BASE + "/"); m.wait_for_load_state("networkidle")
    check("mobile menu hidden then opens", not m.is_visible("#nav") and (m.click("#menu-btn") or m.is_visible("#nav")))
    m.click("#nav a[href='#contact']")
    fill_enquiry(m, pet2=True)
    m.tap("#enquiry-submit"); m.wait_for_selector("#enquiry-done:not([hidden])")
    check("enquiry works on mobile", len(db()["enquiries"]) == 1)
    m.screenshot(path="/tmp/shots/home_mobile.png", full_page=True)
    check("mobile: no CSP violations or JS errors (expected 401/404 probes ignored)", not [x for x in mbag["console"] if "Content Security Policy" in x[1] or "Refused" in x[1]] and not mbag["errors"], str(mbag["console"]))
    mctx.close(); browser.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} browser checks passed")
sys.exit(1 if failed else 0)
