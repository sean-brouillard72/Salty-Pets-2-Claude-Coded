// Local test harness (NOT used in production): serves /public with the exact headers from
// netlify.toml and runs the real Netlify Functions against an in-memory fake of Supabase.
import http from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = new URL('../..', import.meta.url).pathname;
const PORT = Number(process.env.PORT || 8899);
Object.assign(process.env, {
  SUPABASE_URL: 'https://fake.supabase.test', SUPABASE_ANON_KEY: 'anon-key', SUPABASE_SERVICE_ROLE_KEY: 'service-key',
  TURNSTILE_SECRET_KEY: 's', TURNSTILE_SITE_KEY: 'test-site-key', IP_HASH_SECRET: 'x'.repeat(32),
});

// ---- headers from netlify.toml ----
const toml = readFileSync(join(root, 'netlify.toml'), 'utf8');
const headerBlocks = [...toml.matchAll(/\[\[headers\]\]\s+for = "([^"]+)"\s+\[headers\.values\]([\s\S]*?)(?=\n\[\[|\n*$)/g)]
  .map((m) => ({ for: m[1], values: Object.fromEntries([...m[2].matchAll(/^\s*([\w-]+) = "(.*)"\s*$/gm)].map((x) => [x[1], x[2]])) }));
const headersFor = (p) => Object.assign({}, ...headerBlocks.filter((b) => b.for === '/*' || (b.for.endsWith('/*') && p.startsWith(b.for.slice(0, -1)))).map((b) => b.values));

// ---- fake Supabase ----
export const db = { enquiries: [], customers: [], reviews: [], limits: {}, sessions: new Set() };
const J = (body, status = 200) => new Response(body === null ? null : JSON.stringify(body), { status });
const uid = () => crypto.randomUUID();
function fakeSupabase(url, init) {
  const u = new URL(url); const path = u.pathname; const method = init.method || 'GET';
  const body = init.body ? JSON.parse(init.body) : undefined; const h = init.headers || {};
  const bearer = h.Authorization; const isAdmin = bearer === 'Bearer USER-JWT';
  const eq = (name) => u.searchParams.get(name)?.replace(/^eq\./, '');
  if (path === '/auth/v1/token') return u.searchParams.get('grant_type') === 'password'
    ? (body.email === 'owner@example.com' && body.password === 'correct horse' ? J({ access_token: 'USER-JWT', refresh_token: 'RT', expires_in: 3600 }) : J({ error: 'invalid' }, 400))
    : J({}, 401);
  if (path === '/auth/v1/user') return isAdmin && !db.loggedOut ? J({ id: 'u1' }) : J({}, 401);
  if (path === '/auth/v1/logout') { db.loggedOut = true; return J(null, 204); }
  if (path === '/rest/v1/rpc/is_admin') return J(isAdmin);
  if (path === '/rest/v1/rpc/rate_limit_hit') { const k = body.p_key; db.limits[k] = (db.limits[k] || 0) + 1; return J(db.limits[k] <= body.p_limit); }
  if (path === '/rest/v1/rpc/submit_enquiry') {
    const p = body.p; const dup = db.enquiries.find((e) => e.submission_id === p.submission_id);
    if (dup) return J({ reference: dup.reference, duplicate: true });
    let c = db.customers.find((x) => x.phone_e164 === p.phone);
    if (!c) { c = { id: uid(), full_name: p.name, phone_e164: p.phone, email: p.email || null }; db.customers.push(c); }
    const e = { id: uid(), reference: 'SP-' + uid().slice(0, 8).toUpperCase(), submission_id: p.submission_id, customer_id: c.id, service: p.service,
      start_date: p.start_date, end_date: p.end_date || null, preferred_time: p.preferred_time, visits_per_day: p.visits_per_day, frequency: p.frequency,
      specific_times: p.specific_times || null, notes: p.notes || null, status: 'new', estimate_cents: p.estimate_cents, created_at: new Date().toISOString(),
      pets: p.pets.map((x, i) => ({ id: uid(), position: i + 1, animal_type: x.type, name: x.name, breed: x.breed || null, age: x.age || null, notes: x.notes || null })) };
    db.enquiries.push(e); return J({ reference: e.reference, duplicate: false });
  }
  if (path === '/rest/v1/enquiries') {
    if (!isAdmin) return J([], 401);
    if (method === 'GET') { const st = eq('status'); return J(db.enquiries.filter((e) => !st || e.status === st).map((e) => ({ ...e, customers: db.customers.find((c) => c.id === e.customer_id) })).reverse()); }
    const i = db.enquiries.findIndex((e) => e.id === eq('id')); if (i < 0) return J([]);
    if (method === 'PATCH') { db.enquiries[i].status = body.status; return J([db.enquiries[i]]); }
    if (method === 'DELETE') { const [e] = db.enquiries.splice(i, 1); if (!db.enquiries.some((x) => x.customer_id === e.customer_id)) db.customers = db.customers.filter((c) => c.id !== e.customer_id); return J([e]); }
  }
  if (path === '/rest/v1/customers' && method === 'DELETE' && isAdmin) {
    const c = db.customers.find((x) => x.id === eq('id')); if (!c) return J([]);
    db.customers = db.customers.filter((x) => x !== c); db.enquiries = db.enquiries.filter((e) => e.customer_id !== c.id); return J([c]);
  }
  if (path === '/rest/v1/reviews') {
    if (method === 'POST') { if (!db.reviews.some((r) => r.submission_id === body.submission_id)) db.reviews.push({ id: uid(), status: 'pending', created_at: new Date().toISOString(), moderated_at: null, ...body }); return J(null, 201); }
    const st = eq('status');
    if (method === 'GET') {
      if (!isAdmin) return J(db.reviews.filter((r) => r.status === 'approved' && st === 'approved').map(({ reviewer_name, pet_name, rating, content, created_at }) => ({ reviewer_name, pet_name, rating, content, created_at })));
      return J(db.reviews.filter((r) => r.status === st));
    }
    const r = db.reviews.find((x) => x.id === eq('id')); if (!isAdmin || !r) return J([]);
    if (method === 'PATCH') { Object.assign(r, body); return J([r]); }
  }
  return J(null, 404);
}
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init = {}) => {
  const s = String(url);
  if (s.startsWith(process.env.SUPABASE_URL)) return fakeSupabase(s, init);
  if (s.includes('turnstile')) return J({ success: true });
  if (s.includes('resend')) return J({ id: 'x' });
  return realFetch(url, init);
};

// ---- functions ----
const fns = [];
for (const f of ['config', 'enquiry', 'review', 'reviews', 'admin']) {
  const m = await import(pathToFileURL(join(root, 'netlify/functions', f + '.mjs')).href);
  fns.push({ path: m.config.path, handler: m.default });
}
const match = (pattern, p) => (pattern.endsWith('/*') ? p.startsWith(pattern.slice(0, -1)) : p === pattern);
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.txt': 'text/plain' };

http.createServer(async (nreq, nres) => {
  const url = new URL(nreq.url, `http://127.0.0.1:${PORT}`);
  const send = (status, headers, body) => { nres.writeHead(status, { ...headersFor(url.pathname), ...headers }); nres.end(body); };
  if (url.pathname === '/__db') return send(200, { 'content-type': 'application/json' }, JSON.stringify(db));
  if (url.pathname === '/__reset') { db.enquiries = []; db.customers = []; db.reviews = []; db.limits = {}; db.loggedOut = false; return send(200, {}, 'ok'); }
  const fn = fns.find((f) => match(f.path, url.pathname));
  if (fn) {
    const chunks = []; for await (const c of nreq) chunks.push(c);
    const headers = new Headers(); for (const [k, v] of Object.entries(nreq.headers)) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
    const body = ['GET', 'HEAD'].includes(nreq.method) ? undefined : Buffer.concat(chunks);
    const res = await fn.handler(new Request(url, { method: nreq.method, headers, body }), { ip: '127.0.0.1' });
    const out = {}; res.headers.forEach((v, k) => { if (k !== 'set-cookie') out[k] = v; });
    const sc = res.headers.getSetCookie(); if (sc.length) out['set-cookie'] = sc;
    return send(res.status, out, Buffer.from(await res.arrayBuffer()));
  }
  let p = url.pathname;
  if (p === '/admin') return send(301, { location: '/admin/' }, '');
  if (p === '/privacy') p = '/privacy.html';
  if (p.endsWith('/')) p += 'index.html';
  const file = join(root, 'public', p);
  if (!file.startsWith(join(root, 'public')) || !existsSync(file) || statSync(file).isDirectory())
    return send(404, { 'content-type': 'text/html' }, readFileSync(join(root, 'public/404.html')));
  send(200, { 'content-type': MIME[extname(file)] || 'application/octet-stream' }, readFileSync(file));
}).listen(PORT, '127.0.0.1', () => console.log('e2e server on', PORT));
