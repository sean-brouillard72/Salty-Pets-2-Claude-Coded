#!/bin/sh
# Starts the local harness, runs the Chromium test, stops the harness.
cd "$(dirname "$0")/../.." || exit 1
node tests/e2e/server.mjs > /tmp/e2e-server.log 2>&1 &
PID=$!
sleep 1.5
python3 tests/e2e/browser_test.py
CODE=$?
kill $PID 2>/dev/null
exit $CODE
