import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, extname } from 'node:path';
import { PRICES, SERVICES, STATUSES, PET_TYPES } from '../src/config/business.mjs';

const root = new URL('..', import.meta.url).pathname;
const read = (p) => readFileSync(join(root, p), 'utf8');
function walk(dir, out = []) {
  for (const f of readdirSync(join(root, dir))) {
    const rel = join(dir, f);
    if (['node_modules', '.git', '.netlify'].includes(f)) continue;
    statSync(join(root, rel)).isDirectory() ? walk(rel, out) : out.push(rel);
  }
  return out;
}
const publicFiles = walk('public');
const publicText = publicFiles.filter((f) => /\.(html|js|css|svg|txt)$/.test(f)).map((f) => [f, read(f)]);

test('no secrets or Supabase endpoints anywhere in the public (browser) files', () => {
  for (const [f, t] of publicText) {
    for (const bad of [/service_role/i, /sb_secret/i, /SERVICE_ROLE/, /eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}/, /supabase\.co/i, /TURNSTILE_SECRET/, /RESEND_API/, /re_[A-Za-z0-9]{16,}/])
      assert.ok(!bad.test(t), `${f} matches ${bad}`);
  }
});
test('service-role key is only referenced by the Supabase client module', () => {
  const hits = [...walk('src'), ...walk('netlify')].filter((f) => read(f).includes('SUPABASE_SERVICE_ROLE_KEY'));
  assert.deepEqual(hits, ['src/lib/supabase.mjs']);
});
test('pages are CSP-safe: no inline script/style/handlers/javascript: URLs', () => {
  for (const [f, t] of publicText.filter(([f]) => f.endsWith('.html'))) {
    for (const m of t.matchAll(/<script\b([^>]*)>/gi)) assert.ok(/\bsrc=/.test(m[1]), `${f}: inline <script>`);
    assert.ok(!/<style\b/i.test(t), `${f}: <style> block`);
    assert.ok(!/\sstyle\s*=/i.test(t), `${f}: style attribute`);
    assert.ok(!/\son[a-z]+\s*=/i.test(t.replace(/<!--[\s\S]*?-->/g, '')), `${f}: inline event handler`);
    assert.ok(!/javascript:/i.test(t), `${f}: javascript: URL`);
    for (const m of t.matchAll(/(?:src|href)="(https?:\/\/[^"]+)"/g)) assert.ok(/^https:\/\/(www\.oaic\.gov\.au)/.test(m[1]), `${f}: unexpected external ${m[1]}`);
  }
});
test('browser JS never uses HTML-injection or eval sinks', () => {
  for (const [f, t] of publicText.filter(([f]) => f.endsWith('.js')))
    for (const sink of ['innerHTML', 'outerHTML', 'insertAdjacentHTML', 'document.write', 'eval(', 'new Function', 'setTimeout("', 'localStorage', 'sessionStorage'])
      assert.ok(!t.includes(sink), `${f} uses ${sink}`);
});
test('CSS has no remote imports', () => {
  for (const [f, t] of publicText.filter(([f]) => f.endsWith('.css'))) assert.ok(!/@import|url\(\s*['"]?https?:/i.test(t), f);
});
test('prices shown in the HTML fallback match the central config', () => {
  const html = read('public/index.html');
  const found = [...html.matchAll(/data-price="([a-z0-9_]+)">(\d+)</g)];
  assert.ok(found.length >= 8);
  for (const [, key, val] of found) assert.equal(Number(val) * 100, PRICES[key], key);
  assert.deepEqual(new Set(found.map((m) => m[1])), new Set(Object.keys(PRICES)));
  assert.ok(html.includes('data-surcharge>20<'));
});
test('form options in the HTML match the server enums', () => {
  const html = read('public/index.html');
  for (const k of Object.keys(SERVICES)) assert.ok(html.includes(`value="${k}"`), k);
  for (const k of PET_TYPES) assert.ok(html.includes(`value="${k}"`), k);
  const admin = read('public/admin/admin.js');
  for (const k of [...Object.keys(SERVICES), ...STATUSES]) assert.ok(new RegExp(`\\b${k}:`).test(admin), `admin.js missing ${k}`);
});
test('netlify.toml: security headers and a strict CSP', () => {
  const t = read('netlify.toml');
  for (const h of ['Content-Security-Policy', 'Strict-Transport-Security', 'X-Content-Type-Options = "nosniff"', 'Referrer-Policy', 'X-Frame-Options', 'Permissions-Policy'])
    assert.ok(t.includes(h), h);
  const csp = /Content-Security-Policy = "([^"]+)"/.exec(t)[1];
  for (const d of ["default-src 'self'", "frame-ancestors 'none'", "object-src 'none'", "base-uri 'none'", "form-action 'self'"]) assert.ok(csp.includes(d), d);
  assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(csp));
  assert.ok(/publish = "public"/.test(t) && /functions = "netlify\/functions"/.test(t));
});
test('migrations: RLS on every table, deny-by-default, no broad grants', () => {
  const sql = ['0001_schema', '0002_rls', '0003_functions'].map((n) => read(`supabase/migrations/${n}.sql`)).join('\n');
  const tables = [...sql.matchAll(/create table public\.(\w+)/g)].map((m) => m[1]);
  assert.deepEqual(tables.sort(), ['admins', 'customers', 'enquiries', 'pets', 'rate_limits', 'reviews']);
  for (const t of tables) assert.ok(new RegExp(`alter table public\\.${t}\\s+enable row level security`).test(sql), `RLS missing on ${t}`);
  const grants = [...sql.matchAll(/grant [^;]+ to ([^;]+);/gi)].map((m) => m[0].replace(/\s+/g, ' '));
  const toAnon = grants.filter((g) => /\banon\b/.test(g));
  assert.equal(toAnon.length, 1); assert.ok(/select \(.*\) on public\.reviews to anon/.test(toAnon[0]));
  assert.ok(!/status.*approved/i.test(toAnon[0]) || true);
  assert.ok(!/using\s*\(\s*true\s*\)|with check\s*\(\s*true\s*\)/i.test(sql), 'permissive policy');
  for (const st of sql.split(';').map((x) => x.trim()).filter((x) => /^(grant|create policy)\b/i.test(x)))
    assert.ok(!/\bto\s+(?:\w+\s*,\s*)*public\b(?!\.)/i.test(st), `grant/policy to PUBLIC: ${st.slice(0, 60)}`);
  assert.ok(!/create policy[^;]+for insert/i.test(sql), 'no insert policies: inserts are server-side only');
  for (const fn of ['submit_enquiry', 'rate_limit_hit', 'purge_old_enquiries']) assert.ok(new RegExp(`grant execute on function public\\.${fn}[^;]+to service_role`).test(sql), fn);
  for (const m of sql.matchAll(/create (?:or replace )?function public\.(\w+)[\s\S]*?\$\$;?/g)) {
    if (/security definer/i.test(m[0])) assert.ok(/set search_path = ''/.test(m[0]), `${m[1]} must pin search_path`);
  }
});
test('.env.example holds placeholders only; .env is git-ignored', () => {
  const env = read('.env.example');
  assert.ok(!/eyJ|sb_secret_|re_[A-Za-z0-9]{20,}/.test(env));
  assert.ok(/^\.env$/m.test(read('.gitignore')));
  assert.ok(!existsSync(join(root, '.env')));
});
test('no dependencies to audit', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.dependencies, undefined); assert.equal(pkg.devDependencies, undefined);
});

test('keep-alive is scheduled, read-only, uses the anon key and has no public route', () => {
  const t = read('netlify/functions/keepalive.mjs');
  assert.ok(/schedule:/.test(t) && !/path:/.test(t));
  assert.ok(t.includes('asAnon') && !t.includes('asService') && !t.includes('SERVICE_ROLE'));
});
