import test, { beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { setEnv, ENV, req, goodEnquiry, mockFetch, happyNet, future } from './helpers.mjs';
import enquiry from '../netlify/functions/enquiry.mjs';
import review from '../netlify/functions/review.mjs';
import reviews from '../netlify/functions/reviews.mjs';
import cfg from '../netlify/functions/config.mjs';

let net;
const logs = [];
const origLog = console.log;
beforeEach(() => { setEnv(); logs.length = 0; console.log = (s) => logs.push(String(s)); });
afterEach(() => { net?.restore(); console.log = origLog; });
const ctx = { ip: '203.0.113.7' };
const call = (c) => c.url.split('?')[0].split('/').pop();
const post = (body, opts) => enquiry(req('/api/enquiry', { body, ...opts }), ctx);

test('valid enquiry is stored with a SERVER-computed estimate', async () => {
  net = mockFetch(happyNet());
  const r = await post(goodEnquiry({ pets: [{ type: 'dog', name: 'A' }, { type: 'dog', name: 'B' }], service: 'dog_walk_60' }));
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.ok, true); assert.equal(j.reference, 'SP-TEST1234'); assert.equal(j.estimate.totalCents, 4000);
  const rpc = net.calls.find((c) => c.url.includes('submit_enquiry'));
  assert.equal(rpc.body.p.phone, '+61412345678');
  assert.equal(rpc.body.p.estimate_cents, 4000);
  assert.equal(rpc.body.p.pets.length, 2);
  assert.equal(rpc.headers.apikey, ENV.SUPABASE_SERVICE_ROLE_KEY);
});
test('client cannot supply prices, totals, status or ids', async () => {
  net = mockFetch(happyNet());
  for (const extra of [{ estimate_cents: 1 }, { total: 1 }, { price: 1 }, { status: 'accepted' }, { customer_id: crypto.randomUUID() }]) {
    const r = await post({ ...goodEnquiry(), ...extra });
    assert.equal(r.status, 400, JSON.stringify(extra));
  }
  assert.equal(net.calls.filter((c) => c.url.includes('submit_enquiry')).length, 0);
});
test('multiple pets and omitted email', async () => {
  net = mockFetch(happyNet());
  const r = await post(goodEnquiry({ email: '', pets: [{ type: 'cat', name: 'C' }, { type: 'rabbit', name: 'R' }, { type: 'dog', name: 'D' }] }));
  assert.equal(r.status, 200);
  const p = net.calls.find((c) => c.url.includes('submit_enquiry')).body.p;
  assert.equal(p.pets.length, 3); assert.equal(p.email, '');
});
test('invalid phone / date / missing fields -> 400 with field errors, nothing stored', async () => {
  net = mockFetch(happyNet());
  for (const over of [{ phone: '123' }, { start_date: '2001-01-01' }, { name: '' }, { service: 'free_money' }]) {
    const r = await post(goodEnquiry(over));
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error, 'validation');
  }
  assert.equal(net.calls.filter((c) => c.url.includes('submit_enquiry')).length, 0);
});
test('duplicate submission returns the original reference and sends no second email', async () => {
  net = mockFetch((c) => c.url.includes('submit_enquiry') ? { body: { reference: 'SP-ORIG0001', duplicate: true } } : happyNet()(c));
  const r = await post(goodEnquiry());
  const j = await r.json();
  assert.equal(j.duplicate, true); assert.equal(j.reference, 'SP-ORIG0001');
  assert.equal(net.calls.some((c) => c.url.includes('resend')), false);
});
test('database failure: generic error, no internals leaked, no key in logs', async () => {
  net = mockFetch((c) => c.url.includes('submit_enquiry')
    ? { status: 500, body: { message: 'relation "customers" violates SECRET-DB-DETAIL', hint: ENV.SUPABASE_SERVICE_ROLE_KEY } }
    : happyNet()(c));
  const r = await post(goodEnquiry());
  const text = await r.text();
  assert.equal(r.status, 500);
  assert.deepEqual(JSON.parse(text), { error: 'server_error' });
  assert.ok(!text.includes('SECRET'));
  assert.ok(logs.every((l) => !l.includes('SECRET') && !l.includes('Jane') && !l.includes('0412')));
});
test('network exception is handled gracefully', async () => {
  net = mockFetch(() => { throw new TypeError('fetch failed: https://proj.supabase.co SECRET'); });
  const r = await post(goodEnquiry());
  assert.equal(r.status, 500); assert.deepEqual(await r.json(), { error: 'server_error' });
  assert.ok(logs.every((l) => !l.includes('SECRET')));
});
test('email failure never blocks saving', async () => {
  net = mockFetch(happyNet({ 'https://api.resend.com/emails': () => ({ status: 500, body: {} }) }));
  const r = await post(goodEnquiry());
  assert.equal(r.status, 200);
  assert.ok(logs.some((l) => l.includes('email_failed')));
});
test('email notification contains no phone, pet or notes', async () => {
  net = mockFetch(happyNet());
  await post(goodEnquiry({ notes: 'MEDICATION-SECRET', pets: [{ type: 'dog', name: 'Rex', notes: 'PET-HEALTH-SECRET' }] }));
  const mail = net.calls.find((c) => c.url.includes('resend')).body;
  const blob = JSON.stringify(mail);
  assert.ok(blob.includes('SP-TEST1234') && blob.includes('Jane Citizen'));
  for (const s of ['SECRET', '0412', '+61412', 'Rex', 'jane@example.com']) assert.ok(!blob.includes(s), s);
});
test('turnstile failure -> 400 and nothing stored', async () => {
  net = mockFetch(happyNet({ 'https://challenges.cloudflare.com/turnstile/v0/siteverify': () => ({ body: { success: false } }) }));
  const r = await post(goodEnquiry());
  assert.equal(r.status, 400); assert.equal((await r.json()).error, 'captcha');
  assert.equal(net.calls.some((c) => c.url.includes('submit_enquiry')), false);
  const missing = await post(goodEnquiry({ turnstile_token: '' }));
  assert.equal(missing.status, 400);
});
test('rate limit -> 429 with Retry-After; limiter keyed by hashed IP only', async () => {
  net = mockFetch((c) => c.url.includes('rate_limit_hit') ? { body: false } : happyNet()(c));
  const r = await post(goodEnquiry());
  assert.equal(r.status, 429); assert.ok(r.headers.get('retry-after'));
  const key = net.calls.find((c) => c.url.includes('rate_limit_hit')).body.p_key;
  assert.ok(!key.includes('203.0.113.7'));
  assert.equal(net.calls.some((c) => c.url.includes('submit_enquiry') || c.url.includes('turnstile')), false);
});
test('rate limiter failure fails closed', async () => {
  net = mockFetch((c) => c.url.includes('rate_limit_hit') ? { status: 500, body: {} } : happyNet()(c));
  const r = await post(goodEnquiry());
  assert.equal(r.status, 500);
  assert.equal(net.calls.some((c) => c.url.includes('submit_enquiry')), false);
});
test('honeypot: silent fake success, nothing stored', async () => {
  net = mockFetch(happyNet());
  const r = await post(goodEnquiry({ website: 'http://spam.example' }));
  assert.equal(r.status, 200);
  assert.equal(net.calls.length, 0);
});
test('oversized, malformed and wrong-type bodies', async () => {
  net = mockFetch(happyNet());
  assert.equal((await post(goodEnquiry({ notes: 'x'.repeat(40000) }))).status, 413);
  assert.equal((await enquiry(req('/api/enquiry', { raw: '{not json' }), ctx)).status, 400);
  assert.equal((await enquiry(req('/api/enquiry', { raw: 'a=b', headers: { 'content-type': 'text/plain' } }), ctx)).status, 415);
  assert.equal((await enquiry(req('/api/enquiry', { raw: JSON.stringify(Array(20000).fill(1)) }), ctx)).status, 413);
  assert.equal(net.calls.length, 0);
});
test('cross-origin and missing-origin posts, and wrong methods, are refused', async () => {
  net = mockFetch(happyNet());
  assert.equal((await post(goodEnquiry(), { origin: 'https://evil.example' })).status, 403);
  assert.equal((await post(goodEnquiry(), { origin: null })).status, 403);
  assert.equal((await enquiry(req('/api/enquiry', { method: 'GET' }), ctx)).status, 405);
  assert.equal((await enquiry(req('/api/enquiry', { method: 'PUT', body: {} }), ctx)).status, 405);
  assert.equal(net.calls.length, 0);
});
test('missing server configuration fails safely', async () => {
  net = mockFetch(happyNet());
  delete process.env.IP_HASH_SECRET;
  const r = await post(goodEnquiry());
  assert.equal(r.status, 500); assert.deepEqual(await r.json(), { error: 'server_error' });
});
test('injection payloads are passed as data (parameters), never executed or reflected', async () => {
  net = mockFetch(happyNet());
  const sqli = "Robert'); DROP TABLE enquiries;--";
  const xss = '<img src=x onerror=alert(1)>';
  const r = await post(goodEnquiry({ name: sqli, notes: xss, pets: [{ type: 'dog', name: xss, notes: "' OR 1=1 --" }] }));
  assert.equal(r.status, 200);
  const rpc = net.calls.find((c) => c.url.includes('submit_enquiry'));
  assert.equal(rpc.body.p.name, sqli);                       // sent as a JSON parameter to a function
  assert.ok(!(await r.clone().text()).includes('onerror'));  // never reflected in the response
  assert.ok(!rpc.url.includes('DROP'));                      // never concatenated into a URL/query
});

// ---------- reviews ----------
const goodReview = (o = {}) => ({ submission_id: crypto.randomUUID(), turnstile_token: 't', website: '', name: 'Sam', pet_name: 'Rex', rating: 5, content: 'Wonderful, Rex loved it!', consent: true, ...o });
const rpost = (b, o) => review(req('/api/review', { body: b, ...o }), ctx);

test('review: stored as pending with consent; cannot choose status/id', async () => {
  net = mockFetch(happyNet());
  const r = await rpost(goodReview());
  assert.equal(r.status, 200);
  const ins = net.calls.find((c) => c.url.includes('/rest/v1/reviews'));
  assert.equal(ins.body.status, undefined);         // DB default 'pending' applies
  assert.equal(ins.body.publish_consent, true);
  for (const extra of [{ status: 'approved' }, { id: crypto.randomUUID() }, { moderated_at: 'x' }]) {
    assert.equal((await rpost({ ...goodReview(), ...extra })).status, 400, JSON.stringify(extra));
  }
});
test('review: consent, rating, captcha, honeypot, limits', async () => {
  net = mockFetch(happyNet());
  assert.equal((await rpost(goodReview({ consent: false }))).status, 400);
  assert.equal((await rpost(goodReview({ rating: 9 }))).status, 400);
  assert.equal((await rpost(goodReview({ content: 'x'.repeat(2000) }))).status, 400);
  const n = net.calls.length;
  assert.equal((await rpost(goodReview({ website: 'spam' }))).status, 200);
  assert.equal(net.calls.length, n);
  net.restore();
  net = mockFetch(happyNet({ 'https://challenges.cloudflare.com/turnstile/v0/siteverify': () => ({ body: { success: false } }) }));
  assert.equal((await rpost(goodReview())).status, 400);
});
test('review: XSS stays inert text in storage payload', async () => {
  net = mockFetch(happyNet());
  const r = await rpost(goodReview({ content: '<script>alert(document.cookie)</script> great', name: '"><svg onload=alert(1)>' }));
  assert.equal(r.status, 200);
  assert.equal(net.calls.find((c) => c.url.includes('/rest/v1/reviews')).body.content, '<script>alert(document.cookie)</script> great');
});

test('public reviews list uses the ANON key and only the safe columns', async () => {
  net = mockFetch(() => ({ body: [{ reviewer_name: 'A', pet_name: null, rating: 5, content: 'ok', created_at: 'x' }] }));
  const r = await reviews(req('/api/reviews', { method: 'GET' }));
  assert.equal(r.status, 200);
  const c = net.calls[0];
  assert.equal(c.headers.apikey, ENV.SUPABASE_ANON_KEY);
  assert.ok(!JSON.stringify(c.headers).includes('SECRET'));
  assert.ok(c.url.includes('status=eq.approved'));
  assert.ok(!c.url.includes('publish_consent') && !c.url.includes('submission_id') && !c.url.includes('select=*'));
  assert.equal((await reviews(req('/api/reviews', { method: 'POST', body: {} }))).status, 405);
});
test('config endpoint exposes only the public site key and prices', async () => {
  process.env.TURNSTILE_SITE_KEY = 'site-key';
  const j = await (await cfg(req('/api/config', { method: 'GET' }))).json();
  const text = JSON.stringify(j);
  assert.equal(j.turnstileSiteKey, 'site-key');
  for (const secret of Object.values(ENV)) assert.ok(!text.includes(secret), 'leaked ' + secret);
});
