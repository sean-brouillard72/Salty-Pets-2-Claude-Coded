import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEnquiry, validateReview, normalisePhone } from '../src/lib/validate.mjs';
import { goodEnquiry, future } from './helpers.mjs';

const bad = (over) => validateEnquiry(goodEnquiry(over));

test('valid enquiry passes and is normalised', () => {
  const r = validateEnquiry(goodEnquiry());
  assert.ok(r.ok, JSON.stringify(r.errors));
  assert.equal(r.value.phone, '+61412345678');
});
test('email is optional', () => { assert.ok(bad({ email: '' }).ok); assert.ok(bad({ email: undefined }).ok); });
test('multiple pets', () => {
  const r = bad({ pets: [{ type: 'dog', name: 'A' }, { type: 'cat', name: 'B' }, { type: 'fish', name: 'C' }] });
  assert.ok(r.ok); assert.equal(r.value.pets.length, 3);
});
test('australian phone numbers', () => {
  for (const p of ['0412 345 678', '0412345678', '+61 412 345 678', '(08) 9385 1234', '0893851234', '61412345678'])
    assert.ok(normalisePhone(p), p);
  for (const p of ['', '12345', '0512345678', '+1 415 555 2671', '04123', '0412 345 6789', 'abc', '1800 123 456', "0412'; DROP TABLE"])
    assert.equal(normalisePhone(p), null, p);
  assert.ok(bad({ phone: 'nope' }).errors.phone);
});
test('missing required fields', () => {
  for (const f of ['name', 'phone', 'service', 'start_date']) assert.ok(bad({ [f]: '' }).errors[f], f);
  assert.ok(bad({ pets: [] }).errors.pets);
  assert.ok(bad({ pets: [{ type: 'dog', name: '' }] }).errors['pets.0.name']);
  assert.ok(bad({ pets: [{ type: '', name: 'x' }] }).errors['pets.0.type']);
});
test('dates', () => {
  assert.ok(bad({ start_date: '2020-01-01' }).errors.start_date);          // past
  assert.ok(bad({ start_date: '2027-02-30' }).errors.start_date);          // not a real date
  assert.ok(bad({ start_date: '1/2/2027' }).errors.start_date);            // wrong format
  assert.ok(bad({ start_date: future(900) }).errors.start_date);           // too far ahead
  assert.ok(bad({ start_date: future(10), end_date: future(5) }).errors.end_date);
  assert.ok(bad({ start_date: future(10), end_date: future(200) }).errors.end_date);
  assert.ok(bad({ end_date: 'tomorrow' }).errors.end_date);
});
test('enumerations are enforced', () => {
  for (const f of ['service', 'preferred_time', 'frequency', 'visits_per_day']) assert.ok(bad({ [f]: 'hack' }).errors[f], f);
  assert.ok(bad({ pets: [{ type: 'dragon', name: 'x' }] }).errors['pets.0.type']);
});
test('dog walks need a dog', () => {
  assert.ok(bad({ service: 'dog_walk_30', pets: [{ type: 'cat', name: 'Tom' }] }).errors.service);
  assert.ok(bad({ service: 'home_visit', pets: [{ type: 'cat', name: 'Tom' }] }).ok);
});
test('length limits and max pets', () => {
  assert.ok(bad({ name: 'x'.repeat(101) }).errors.name);
  assert.ok(bad({ notes: 'x'.repeat(2001) }).errors.notes);
  assert.ok(bad({ email: 'a'.repeat(250) + '@x.com' }).errors.email);
  const many = Array.from({ length: 9 }, () => ({ type: 'dog', name: 'd' }));
  assert.ok(bad({ pets: many }).errors.pets);
});
test('unexpected fields are rejected (price/status tampering)', () => {
  for (const extra of [{ price: 1 }, { estimate_cents: 1 }, { status: 'accepted' }, { total: 0 }, { customer_id: 'x' }, { __proto__x: 1 }]) {
    const r = validateEnquiry({ ...goodEnquiry(), ...extra });
    assert.equal(r.code, 'unexpected_fields', JSON.stringify(extra));
  }
  assert.equal(validateEnquiry({ ...goodEnquiry(), pets: [{ type: 'dog', name: 'x', id: 'y' }] }).ok, false);
  assert.equal(validateEnquiry(JSON.parse('{"__proto__":{"x":1}}')).ok, false);
  for (const nonObj of [null, 'str', 5, [], undefined]) assert.equal(validateEnquiry(nonObj).ok, false);
});
test('wrong types do not crash', () => {
  const r = validateEnquiry({ ...goodEnquiry(), name: { a: 1 }, phone: 5, email: [], notes: 7, pets: 'x', service: {}, start_date: 5 });
  assert.equal(r.ok, false);
});
test('control and bidi characters are stripped; XSS text is kept as inert text', () => {
  const r = bad({ name: 'Jo\u0000\u202Ehn', notes: '<script>alert(1)</script>\r\nline2' });
  assert.ok(r.ok);
  assert.equal(r.value.name, 'John');
  assert.equal(r.value.notes, '<script>alert(1)</script>\nline2'); // stored verbatim; rendered with textContent only
});
test('review validation', () => {
  const ok = { submission_id: crypto.randomUUID(), name: 'Sam', pet_name: 'Rex', rating: 5, content: 'Fantastic service!', consent: true };
  assert.ok(validateReview(ok).ok);
  assert.ok(validateReview({ ...ok, consent: false }).errors.consent);
  assert.ok(validateReview({ ...ok, consent: 'true' }).errors.consent);
  assert.ok(validateReview({ ...ok, rating: 6 }).errors.rating);
  assert.ok(validateReview({ ...ok, rating: 0 }).errors.rating);
  assert.ok(validateReview({ ...ok, rating: 4.5 }).errors.rating);
  assert.ok(validateReview({ ...ok, content: 'short' }).errors.content);
  assert.equal(validateReview({ ...ok, status: 'approved' }).code, 'unexpected_fields');
  assert.equal(validateReview({ ...ok, id: crypto.randomUUID() }).code, 'unexpected_fields');
});
