import test from 'node:test';
import assert from 'node:assert/strict';
import { estimate } from '../src/lib/pricing.mjs';
import { PRICES } from '../src/config/business.mjs';

const dogs = (n) => Array.from({ length: n }, (_, i) => ({ type: 'dog', name: `D${i}` }));
const base = { frequency: 'one_off', visits_per_day: 1, start_date: '2027-02-01', end_date: '' };
const total = (v) => estimate(v)?.totalCents;

test('dog walks', () => {
  assert.equal(total({ ...base, service: 'dog_walk_30', pets: dogs(1) }), 2000);
  assert.equal(total({ ...base, service: 'dog_walk_60', pets: dogs(1) }), 3500);
  assert.equal(total({ ...base, service: 'dog_walk_30', pets: dogs(3) }), 3000);       // +$5 x 2
  assert.equal(total({ ...base, service: 'dog_walk_60', pets: dogs(2), visits_per_day: 2 }), 8000);
});
test('home visits: extra dogs only; other pets cost nothing extra', () => {
  assert.equal(total({ ...base, service: 'home_visit', pets: [{ type: 'cat', name: 'C' }, { type: 'bird', name: 'B' }] }), 2000);
  assert.equal(total({ ...base, service: 'home_visit', pets: dogs(2) }), 2500);
});
test('multi-day visit block (daily)', () => {
  assert.equal(total({ ...base, service: 'home_visit', pets: dogs(1), end_date: '2027-02-03' }), 6000);
});
test('boarding and overnight are per night', () => {
  const b = { ...base, start_date: '2027-02-01', end_date: '2027-02-04' };
  assert.equal(total({ ...b, service: 'boarding', pets: dogs(1) }), 3 * 3500);
  assert.equal(total({ ...b, service: 'boarding', pets: dogs(2) }), 3 * 4500);
  assert.equal(total({ ...b, service: 'overnight', pets: dogs(2) }), 3 * 4500);
});
test('public holiday surcharge is 20% per affected day only', () => {
  // 25 Dec 2026 is a public holiday; 24 Dec is not.
  const e = estimate({ ...base, service: 'overnight', pets: dogs(1), start_date: '2026-12-24', end_date: '2026-12-26' });
  assert.equal(e.totalCents, 4500 + 4500 * 1.2);
  assert.deepEqual(e.breakdown.holidayDates, ['2026-12-25']);
  assert.equal(total({ ...base, service: 'dog_walk_60', pets: dogs(1), start_date: '2027-01-26' }), 4200);
});
test('no estimate when it would be a guess', () => {
  assert.equal(estimate({ ...base, service: 'dog_walk_30', pets: dogs(1), frequency: 'weekly' }), null);
  assert.equal(estimate({ ...base, service: 'boarding', pets: dogs(1) }), null);            // no end date
  assert.equal(estimate({ ...base, service: 'not_sure', pets: dogs(1) }), null);
  assert.equal(estimate({ ...base, service: 'meet_and_greet', pets: dogs(1) }).totalCents, 0);
});
test('price table is in cents and integer', () => {
  for (const v of Object.values(PRICES)) assert.ok(Number.isInteger(v) && v > 0);
});
