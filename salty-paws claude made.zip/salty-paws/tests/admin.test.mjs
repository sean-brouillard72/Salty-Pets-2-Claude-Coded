import test, { beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { setEnv, ENV, req, mockFetch } from './helpers.mjs';
import admin from '../netlify/functions/admin.mjs';

let net;
const origLog = console.log;
beforeEach(() => { setEnv(); console.log = () => {}; });
afterEach(() => { net?.restore(); console.log = origLog; });
const ctx = { ip: '198.51.100.9' };
const CSRF = { 'x-requested-with': 'salty-paws' };
const UUID = '11111111-1111-4111-8111-111111111111';
const withCookie = (h = {}) => ({ cookie: 'sp_at=USER-JWT; sp_rt=REFRESH', ...h });

// Fake Supabase: token USER-JWT is a valid admin session.
const supa = ({ admin = true, patchRows = [{ id: UUID }], tokenOk = true } = {}) => (c) => {
  const bearer = c.headers.Authorization;
  if (c.url.includes('/auth/v1/user')) return bearer === 'Bearer USER-JWT' && tokenOk ? { body: { id: 'u1' } } : { status: 401, body: {} };
  if (c.url.includes('grant_type=refresh_token')) return { status: 401, body: {} };
  if (c.url.includes('/auth/v1/logout')) return { status: 204, body: null };
  if (c.url.includes('grant_type=password')) return c.body.password === 'right'
    ? { body: { access_token: 'USER-JWT', refresh_token: 'RT', expires_in: 3600 } } : { status: 400, body: { error: 'invalid_grant' } };
  if (c.url.includes('/rpc/rate_limit_hit')) return { body: true };
  if (c.url.includes('/rpc/is_admin')) return { body: bearer === 'Bearer USER-JWT' && admin };
  if (c.url.includes('/rest/v1/')) return c.method === 'GET' ? { body: [] } : { body: patchRows };
  return { status: 404, body: null };
};
const A = (path, o = {}) => admin(req('/api/admin' + path, o), ctx);

test('every protected route rejects unauthenticated requests', async () => {
  net = mockFetch(supa());
  const routes = [['GET', '/session'], ['GET', '/enquiries'], ['GET', '/reviews'],
    ['PATCH', `/enquiries/${UUID}`, { status: 'accepted' }], ['DELETE', `/enquiries/${UUID}`], ['DELETE', `/customers/${UUID}`],
    ['PATCH', `/reviews/${UUID}`, { status: 'approved' }]];
  for (const [method, path, body] of routes) {
    const r = await A(path, { method, body, headers: CSRF });
    assert.equal(r.status, 401, `${method} ${path}`);
  }
  assert.equal(net.calls.some((c) => c.url.includes('/rest/v1/enquiries') || c.url.includes('/rest/v1/reviews')), false);
});
test('invalid / expired token is rejected', async () => {
  net = mockFetch(supa({ tokenOk: false }));
  assert.equal((await A('/enquiries', { method: 'GET', headers: { cookie: 'sp_at=FORGED' } })).status, 401);
  assert.equal((await A('/enquiries', { method: 'GET', headers: { cookie: 'sp_at=USER-JWT' } })).status, 401);
});
test('a valid Supabase user who is NOT in admins gets nothing', async () => {
  net = mockFetch(supa({ admin: false }));
  const r = await A('/enquiries', { method: 'GET', headers: withCookie() });
  assert.equal(r.status, 401);
  assert.equal(net.calls.some((c) => c.url.includes('/rest/v1/enquiries')), false);
});
test('admin reads use the USER token + anon key, never the service-role key', async () => {
  net = mockFetch(supa());
  const r = await A('/enquiries?status=new', { method: 'GET', headers: withCookie() });
  assert.equal(r.status, 200);
  const q = net.calls.find((c) => c.url.includes('/rest/v1/enquiries'));
  assert.equal(q.headers.Authorization, 'Bearer USER-JWT');
  assert.equal(q.headers.apikey, ENV.SUPABASE_ANON_KEY);
  assert.ok(q.url.includes('status=eq.new'));
  assert.ok(!JSON.stringify(net.calls.filter((c) => !c.url.includes('rate_limit')).map((c) => c.headers)).includes('SECRET'));
});
test('state-changing requests need same Origin AND the custom header (CSRF)', async () => {
  net = mockFetch(supa());
  const body = { status: 'accepted' };
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body, headers: withCookie() })).status, 403);               // no header
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body, headers: withCookie(CSRF), origin: 'https://evil.example' })).status, 403);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body, headers: withCookie(CSRF), origin: null })).status, 403);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'DELETE', headers: withCookie() })).status, 403);
  assert.equal((await A('/login', { body: { email: 'a@b.c', password: 'right' } })).status, 403);
  assert.equal(net.calls.length, 0);
});
test('input validation: ids, statuses, extra fields (no filter/SQL injection)', async () => {
  net = mockFetch(supa());
  const h = withCookie(CSRF);
  assert.equal((await A('/enquiries/not-a-uuid', { method: 'PATCH', body: { status: 'new' }, headers: h })).status, 400);
  assert.equal((await A(`/enquiries/${UUID}%26select=*`, { method: 'DELETE', headers: h })).status, 400);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body: { status: 'hacked' }, headers: h })).status, 400);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body: { status: 'new', customer_id: UUID }, headers: h })).status, 400);
  assert.equal((await A(`/reviews/${UUID}`, { method: 'PATCH', body: { status: 'new' }, headers: h })).status, 400); // wrong enum for reviews
  assert.equal((await A('/enquiries?status=new%26or=(id.neq.0)', { method: 'GET', headers: withCookie() })).status, 400);
  assert.equal((await A('/reviews?status=x', { method: 'GET', headers: withCookie() })).status, 400);
  assert.equal(net.calls.some((c) => c.method !== 'GET' && c.url.includes('/rest/v1/') && !c.url.includes('/rpc/')), false);
});
test('admin can update status, moderate reviews, delete; missing rows give 404', async () => {
  net = mockFetch(supa());
  const h = withCookie(CSRF);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'PATCH', body: { status: 'accepted' }, headers: h })).status, 200);
  const rv = await A(`/reviews/${UUID}`, { method: 'PATCH', body: { status: 'approved' }, headers: h });
  assert.equal(rv.status, 200);
  assert.equal(net.calls.at(-1).body.status, 'approved'); assert.ok(net.calls.at(-1).body.moderated_at);
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'DELETE', headers: h })).status, 200);
  assert.equal((await A(`/customers/${UUID}`, { method: 'DELETE', headers: h })).status, 200);
  net.restore(); net = mockFetch(supa({ patchRows: [] })); // RLS hid / row doesn't exist
  assert.equal((await A(`/enquiries/${UUID}`, { method: 'DELETE', headers: h })).status, 404);
});
test('login: success sets HttpOnly/Secure/SameSite=Strict cookies scoped to /api/admin', async () => {
  net = mockFetch(supa());
  const r = await A('/login', { body: { email: 'owner@example.com', password: 'right' }, headers: CSRF });
  assert.equal(r.status, 200);
  const cookies = r.headers.getSetCookie();
  assert.equal(cookies.length, 2);
  for (const c of cookies) for (const flag of ['HttpOnly', 'Secure', 'SameSite=Strict', 'Path=/api/admin']) assert.ok(c.includes(flag), `${c} missing ${flag}`);
  assert.ok(!(await r.text()).includes('USER-JWT'));  // token never in the body
});
test('login: wrong password and non-admin give the same generic 401', async () => {
  net = mockFetch(supa());
  const bad = await A('/login', { body: { email: 'owner@example.com', password: 'wrong' }, headers: CSRF });
  net.restore(); net = mockFetch(supa({ admin: false }));
  const notAdmin = await A('/login', { body: { email: 'rando@example.com', password: 'right' }, headers: CSRF });
  assert.equal(bad.status, 401); assert.equal(notAdmin.status, 401);
  assert.equal(await bad.text(), await notAdmin.text());
  assert.equal(notAdmin.headers.getSetCookie().length, 0);
  assert.ok(net.calls.some((c) => c.url.includes('/auth/v1/logout')));   // stray session revoked
});
test('login is rate limited', async () => {
  net = mockFetch((c) => c.url.includes('rate_limit_hit') ? { body: false } : supa()(c));
  const r = await A('/login', { body: { email: 'a@b.c', password: 'x' }, headers: CSRF });
  assert.equal(r.status, 429);
  assert.equal(net.calls.some((c) => c.url.includes('grant_type=password')), false);
});
test('logout clears cookies and revokes the session server-side', async () => {
  net = mockFetch(supa());
  const r = await A('/logout', { headers: withCookie(CSRF), body: {} });
  assert.equal(r.status, 200);
  for (const c of r.headers.getSetCookie()) assert.ok(c.includes('Max-Age=0'));
  assert.ok(net.calls.some((c) => c.url.includes('/auth/v1/logout')));
  net.restore(); net = mockFetch(supa());
  assert.equal((await A('/session', { method: 'GET', headers: { cookie: 'sp_at=; sp_rt=' } })).status, 401);
});
test('unknown route is 404 for admins, 401 for others', async () => {
  net = mockFetch(supa());
  assert.equal((await A('/nope', { method: 'GET', headers: withCookie() })).status, 404);
  assert.equal((await A('/nope', { method: 'GET' })).status, 401);
});
