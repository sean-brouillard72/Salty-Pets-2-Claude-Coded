(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const MAX_PETS = 8;
  const state = { turnstileKey: '', widgets: {} };

  // ---------- nav ----------
  const menuBtn = $('#menu-btn');
  const nav = $('#nav');
  menuBtn.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', String(open));
  });
  nav.addEventListener('click', (e) => {
    if (e.target.closest('a')) { nav.classList.remove('open'); menuBtn.setAttribute('aria-expanded', 'false'); }
  });

  // ---------- helpers ----------
  const perthToday = () => new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
  const newId = () => (crypto.randomUUID ? crypto.randomUUID() : '');
  const dollars = (cents) => (cents % 100 === 0 ? String(cents / 100) : (cents / 100).toFixed(2));
  const setStatus = (el, msg, kind, list) => {
    el.className = 'status' + (kind ? ' ' + kind : '');
    el.textContent = msg || '';
    if (list && list.length) {
      const ul = document.createElement('ul');
      for (const m of list) { const li = document.createElement('li'); li.textContent = m; ul.append(li); }
      el.append(ul);
    }
  };
  const fieldMessages = (fields) => {
    const out = [];
    for (const [k, v] of Object.entries(fields || {})) {
      const m = /^pets\.(\d+)\./.exec(k) || /^pets\.(\d+)$/.exec(k);
      out.push(m ? `Pet ${Number(m[1]) + 1}: ${v}` : String(v));
    }
    return out;
  };
  async function post(url, body) {
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    let data = {};
    try { data = await res.json(); } catch { /* non-JSON error page */ }
    return { status: res.status, data };
  }
  function friendlyError(status, data) {
    if (status === 429) return { msg: 'You’ve sent a few requests in a short time. Please wait a little and try again, or call or text me.' };
    if (data.error === 'captcha') return { msg: 'We couldn’t verify you’re human. Please try the check again.' };
    if (data.error === 'validation') return { msg: 'Please fix the following:', list: fieldMessages(data.fields) };
    if (status === 413) return { msg: 'That was too long. Please shorten your message.' };
    return { msg: 'Sorry, something went wrong on our side. Please try again, or call or text me on 0422 361 447.' };
  }

  // ---------- Turnstile ----------
  function renderTurnstile() {
    if (!window.turnstile || !state.turnstileKey) return;
    for (const [id, key] of [['#ts-enquiry', 'enquiry'], ['#ts-review', 'review']]) {
      if (!state.widgets[key]) state.widgets[key] = window.turnstile.render(id, { sitekey: state.turnstileKey });
    }
  }
  const tsToken = (key) => (window.turnstile && state.widgets[key] !== undefined ? window.turnstile.getResponse(state.widgets[key]) || '' : '');
  const tsReset = (key) => { if (window.turnstile && state.widgets[key] !== undefined) window.turnstile.reset(state.widgets[key]); };

  async function loadConfig() {
    try {
      const res = await fetch('/api/config');
      const cfg = await res.json();
      for (const el of document.querySelectorAll('[data-price]')) {
        const c = cfg.prices && cfg.prices[el.dataset.price];
        if (Number.isInteger(c)) el.textContent = dollars(c);
      }
      for (const el of document.querySelectorAll('[data-surcharge]')) {
        if (Number.isInteger(cfg.holidaySurchargePercent)) el.textContent = String(cfg.holidaySurchargePercent);
      }
      state.turnstileKey = cfg.turnstileSiteKey || '';
    } catch { /* keep the static text */ }
    if (!state.turnstileKey) {
      for (const [s, b] of [['#enquiry-status', '#enquiry-submit'], ['#review-status', '#review-form button[type=submit]']]) {
        setStatus($(s), 'The form is temporarily unavailable. Please call or text 0422 361 447.', 'err');
        $(b).disabled = true;
      }
      return;
    }
    const sc = document.createElement('script');
    sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    sc.async = true;
    sc.onload = renderTurnstile;
    document.head.append(sc);
  }

  // ---------- pets ----------
  const petsEl = $('#pets');
  const petTpl = $('#pet-template');
  function renumberPets() {
    const pets = petsEl.querySelectorAll('.pet');
    pets.forEach((p, i) => {
      $('.pet-title', p).textContent = `Pet ${i + 1}`;
      $('.remove-pet', p).hidden = pets.length === 1;
    });
    $('#add-pet').hidden = pets.length >= MAX_PETS;
  }
  function addPet() {
    if (petsEl.querySelectorAll('.pet').length >= MAX_PETS) return;
    petsEl.append(petTpl.content.cloneNode(true));
    renumberPets();
  }
  $('#add-pet').addEventListener('click', addPet);
  petsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.remove-pet');
    if (btn) { btn.closest('.pet').remove(); renumberPets(); }
  });

  // ---------- enquiry ----------
  const form = $('#enquiry-form');
  const status = $('#enquiry-status');
  const submitBtn = $('#enquiry-submit');
  let submissionId = newId();
  form.elements.start_date.min = perthToday();
  form.elements.end_date.min = perthToday();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (submitBtn.disabled) return; // guards double-clicks
    if (!form.reportValidity()) return;
    const f = form.elements;
    const token = tsToken('enquiry');
    if (!token) { setStatus(status, 'Please complete the verification check above the button.', 'err'); return; }
    const payload = {
      submission_id: submissionId, turnstile_token: token, website: f.website.value,
      name: f.name.value, phone: f.phone.value, email: f.email.value,
      pets: [...petsEl.querySelectorAll('.pet')].map((p) => ({
        type: $('[data-f=type]', p).value, name: $('[data-f=name]', p).value, breed: $('[data-f=breed]', p).value,
        age: $('[data-f=age]', p).value, notes: $('[data-f=notes]', p).value,
      })),
      service: f.service.value, start_date: f.start_date.value, end_date: f.end_date.value,
      preferred_time: f.preferred_time.value, visits_per_day: f.visits_per_day.value, frequency: f.frequency.value,
      specific_times: f.specific_times.value, notes: f.notes.value,
    };
    submitBtn.disabled = true;
    setStatus(status, 'Sending…');
    try {
      const { status: code, data } = await post('/api/enquiry', payload);
      if (code === 200 && data.ok) {
        $('#done-ref').textContent = data.reference;
        const est = $('#done-estimate');
        est.textContent = '';
        if (data.estimate && !data.estimate.free) {
          est.textContent = `Indicative estimate: $${dollars(data.estimate.totalCents)}` +
            (data.estimate.holidaySurcharge ? ' (includes the public holiday surcharge)' : '') +
            '. This is not a quote; the final price is confirmed when we agree your booking.';
        }
        form.hidden = true;
        const done = $('#enquiry-done');
        done.hidden = false;
        done.focus();
        setStatus(status, '');
      } else {
        const m = friendlyError(code, data);
        setStatus(status, m.msg, 'err', m.list);
        tsReset('enquiry');
        submitBtn.disabled = false;
      }
    } catch {
      setStatus(status, 'We couldn’t reach the server. Please check your connection and try again.', 'err');
      tsReset('enquiry');
      submitBtn.disabled = false;
    }
  });
  $('#again').addEventListener('click', () => {
    form.reset();
    petsEl.textContent = '';
    addPet();
    submissionId = newId();
    submitBtn.disabled = false;
    tsReset('enquiry');
    $('#enquiry-done').hidden = true;
    form.hidden = false;
  });

  // ---------- reviews ----------
  const rform = $('#review-form');
  const rstatus = $('#review-status');
  const rbtn = $('button[type=submit]', rform);
  let reviewId = newId();
  rform.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (rbtn.disabled) return;
    if (!rform.reportValidity()) return;
    const f = rform.elements;
    const token = tsToken('review');
    if (!token) { setStatus(rstatus, 'Please complete the verification check above the button.', 'err'); return; }
    rbtn.disabled = true;
    setStatus(rstatus, 'Sending…');
    try {
      const { status: code, data } = await post('/api/review', {
        submission_id: reviewId, turnstile_token: token, website: f.website.value, name: f.name.value,
        pet_name: f.pet_name.value, rating: Number(f.rating.value), content: f.content.value, consent: f.consent.checked,
      });
      if (code === 200 && data.ok) {
        rform.reset();
        reviewId = newId();
        setStatus(rstatus, 'Thank you! Your review has been received. I’ll check it with you before it appears on the page.', 'ok');
      } else {
        const m = friendlyError(code, data);
        setStatus(rstatus, m.msg, 'err', m.list);
      }
    } catch {
      setStatus(rstatus, 'We couldn’t reach the server. Please try again.', 'err');
    }
    tsReset('review');
    rbtn.disabled = false;
  });

  async function loadReviews() {
    try {
      const res = await fetch('/api/reviews');
      const { reviews } = await res.json();
      if (!Array.isArray(reviews) || reviews.length === 0) return;
      const list = $('#review-list');
      for (const r of reviews) {
        const card = document.createElement('article');
        card.className = 'review';
        const stars = document.createElement('div');
        stars.className = 'stars';
        const n = Math.max(1, Math.min(5, Number(r.rating) || 0));
        stars.textContent = '★'.repeat(n) + '☆'.repeat(5 - n);
        stars.setAttribute('role', 'img');
        stars.setAttribute('aria-label', `${n} out of 5 stars`);
        const p = document.createElement('p');
        p.textContent = String(r.content); // textContent: HTML in a review can never execute
        const who = document.createElement('p');
        who.className = 'who';
        who.textContent = '— ' + String(r.reviewer_name) + (r.pet_name ? ` (owner of ${r.pet_name})` : '');
        card.append(stars, p, who);
        list.append(card);
      }
      $('#review-empty').hidden = true;
    } catch { /* leave the "no reviews yet" message */ }
  }

  addPet();
  loadConfig();
  loadReviews();
})();
