(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const SERVICES = {
    meet_and_greet: 'Free meet and greet', dog_walk_30: 'Dog walk (30 min)', dog_walk_60: 'Dog walk (1 hour)',
    home_visit: 'Home visits', boarding: 'Boarding at my property', overnight: 'Overnight in their home', not_sure: 'Not sure yet',
  };
  const STATUSES = { new: 'New', contacted: 'Contacted', awaiting_response: 'Awaiting response', accepted: 'Accepted', declined: 'Declined', completed: 'Completed' };
  const TIMES = { flexible: 'Flexible', early_morning: 'Early morning (6–9am)', morning: 'Morning (9am–12pm)', midday: 'Midday (12–2pm)', afternoon: 'Afternoon (2–5pm)', evening: 'Evening (5–8pm)' };
  const FREQ = { one_off: 'One-off', weekly: 'Regular (weekly)', several_weekly: 'Regular (several days a week)', not_sure: 'Not sure yet' };
  const PETS = { dog: 'Dog', cat: 'Cat', bird: 'Bird', rabbit: 'Rabbit', guinea_pig: 'Guinea pig', fish: 'Fish', reptile: 'Reptile', other: 'Other' };

  // Safe DOM builder: strings are always inserted as text, never as HTML.
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v; else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    for (const kid of kids.flat()) if (kid !== null && kid !== undefined) el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
    return el;
  }
  const when = (iso) => new Date(iso).toLocaleString('en-AU', { timeZone: 'Australia/Perth', dateStyle: 'medium', timeStyle: 'short' });
  const money = (c) => `$${(c / 100).toFixed(2)}`;

  async function api(method, path, body) {
    const res = await fetch('/api/admin' + path, {
      method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'salty-paws' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = {};
    try { data = await res.json(); } catch { /* ignore */ }
    if (res.status === 401 && path !== '/login') { showLogin(); throw new Error('unauthorised'); }
    return { ok: res.ok, status: res.status, data };
  }

  const loginSec = $('#login'), appSec = $('#app'), logoutBtn = $('#logout'), appStatus = $('#app-status');
  const say = (msg, ok) => { appStatus.className = 'status ' + (ok ? 'ok' : 'err'); appStatus.textContent = msg || ''; };
  function showLogin() { loginSec.hidden = false; appSec.hidden = true; logoutBtn.hidden = true; $('#enquiry-list').textContent = ''; $('#review-list').textContent = ''; }
  function showApp() { loginSec.hidden = true; appSec.hidden = false; logoutBtn.hidden = false; }

  // ---- login / logout ----
  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target.elements, st = $('#login-status');
    st.className = 'status'; st.textContent = 'Signing in…';
    try {
      const r = await api('POST', '/login', { email: f.email.value, password: f.password.value });
      f.password.value = '';
      if (r.ok) { st.textContent = ''; showApp(); loadEnquiries(); }
      else { st.className = 'status err'; st.textContent = r.status === 429 ? 'Too many attempts. Please wait 15 minutes.' : 'Those details didn’t work.'; }
    } catch { st.className = 'status err'; st.textContent = 'Could not reach the server.'; }
  });
  logoutBtn.addEventListener('click', async () => { try { await api('POST', '/logout'); } catch { /* ignore */ } showLogin(); });

  // ---- tabs ----
  const tabs = { enquiries: [$('#tab-enquiries'), $('#panel-enquiries')], reviews: [$('#tab-reviews'), $('#panel-reviews')] };
  function selectTab(name) {
    for (const [k, [tab, panel]] of Object.entries(tabs)) { tab.setAttribute('aria-selected', String(k === name)); panel.hidden = k !== name; }
    say('');
    if (name === 'enquiries') loadEnquiries(); else loadReviews();
  }
  tabs.enquiries[0].addEventListener('click', () => selectTab('enquiries'));
  tabs.reviews[0].addEventListener('click', () => selectTab('reviews'));

  // ---- enquiries ----
  const filter = $('#enquiry-filter');
  for (const [v, l] of Object.entries(STATUSES)) filter.append(h('option', { value: v }, l));
  filter.addEventListener('change', loadEnquiries);
  $('#refresh-enquiries').addEventListener('click', loadEnquiries);

  async function loadEnquiries() {
    const list = $('#enquiry-list');
    try {
      const r = await api('GET', '/enquiries' + (filter.value ? `?status=${encodeURIComponent(filter.value)}` : ''));
      if (!r.ok) { say('Could not load enquiries.'); return; }
      list.textContent = '';
      if (!r.data.enquiries.length) list.append(h('p', {}, 'No enquiries to show.'));
      for (const q of r.data.enquiries) list.append(enquiryItem(q));
    } catch { /* login screen already shown */ }
  }

  function enquiryItem(q) {
    const c = q.customers || {};
    const pets = (q.pets || []).slice().sort((a, b) => a.position - b.position);
    const sel = h('select', { 'aria-label': 'Status' }, Object.entries(STATUSES).map(([v, l]) => h('option', { value: v, selected: v === q.status }, l)));
    const badge = h('span', { class: `badge ${q.status}` }, STATUSES[q.status] || q.status);
    const row = (k, v) => (v ? [h('dt', {}, k), h('dd', {}, v)] : []);
    const dates = q.start_date + (q.end_date ? ` to ${q.end_date}` : '');
    const est = q.estimate_cents === null || q.estimate_cents === undefined ? 'Not calculated (recurring or unclear)' : money(q.estimate_cents);
    const details = h('div', { class: 'detail' },
      h('dl', {},
        row('Customer', c.full_name), c.phone_e164 ? [h('dt', {}, 'Phone'), h('dd', {}, h('a', { href: `tel:${c.phone_e164}` }, c.phone_e164))] : [],
        c.email ? [h('dt', {}, 'Email'), h('dd', {}, h('a', { href: `mailto:${c.email}` }, c.email))] : [],
        row('Service', SERVICES[q.service] || q.service), row('Dates', dates), row('Preferred time', TIMES[q.preferred_time]),
        row('Visits per day', q.visits_per_day ? String(q.visits_per_day) : 'Not applicable'), row('How often', FREQ[q.frequency]),
        row('Specific times', q.specific_times), row('Notes', q.notes), row('Indicative estimate', est), row('Received', when(q.created_at))),
      h('table', {}, h('thead', {}, h('tr', {}, ['Type', 'Name', 'Breed', 'Age', 'Notes'].map((t) => h('th', {}, t)))),
        h('tbody', {}, pets.map((p) => h('tr', {}, h('td', {}, PETS[p.animal_type] || p.animal_type), h('td', {}, p.name), h('td', {}, p.breed || ''), h('td', {}, p.age || ''), h('td', {}, p.notes || ''))))),
      h('div', { class: 'actions' }, sel,
        h('button', { type: 'button', class: 'btn small', on: { click: async () => {
          const r = await api('PATCH', `/enquiries/${q.id}`, { status: sel.value });
          if (r.ok) { say(`Updated ${q.reference}.`, true); badge.className = `badge ${sel.value}`; badge.textContent = STATUSES[sel.value]; } else say('Could not update the status.');
        } } }, 'Save status'),
        h('button', { type: 'button', class: 'btn small danger', on: { click: async () => {
          if (!confirm(`Delete enquiry ${q.reference} and its pet details? This can’t be undone.`)) return;
          const r = await api('DELETE', `/enquiries/${q.id}`);
          if (r.ok) { say(`Deleted ${q.reference}.`, true); loadEnquiries(); } else say('Could not delete the enquiry.');
        } } }, 'Delete enquiry'),
        h('button', { type: 'button', class: 'btn small danger', on: { click: async () => {
          if (!confirm(`Delete ${c.full_name} and ALL of their enquiries and pets? This can’t be undone.`)) return;
          const r = await api('DELETE', `/customers/${q.customer_id}`);
          if (r.ok) { say('Customer and all related data deleted.', true); loadEnquiries(); } else say('Could not delete the customer.');
        } } }, 'Delete customer and all data')));
    return h('details', { class: 'item' },
      h('summary', {}, h('span', { class: 'ref' }, q.reference), badge, h('span', {}, c.full_name || ''), h('span', { class: 'meta' }, `${SERVICES[q.service] || q.service} · ${q.start_date} · received ${when(q.created_at)}`)),
      details);
  }

  // ---- reviews ----
  const rfilter = $('#review-filter');
  rfilter.addEventListener('change', loadReviews);
  $('#refresh-reviews').addEventListener('click', loadReviews);

  async function loadReviews() {
    const list = $('#review-list');
    try {
      const r = await api('GET', `/reviews?status=${encodeURIComponent(rfilter.value)}`);
      if (!r.ok) { say('Could not load reviews.'); return; }
      list.textContent = '';
      if (!r.data.reviews.length) list.append(h('p', {}, 'No reviews to show.'));
      for (const v of r.data.reviews) list.append(reviewItem(v));
    } catch { /* login screen already shown */ }
  }

  function reviewItem(v) {
    const act = (status, label, cls) => h('button', { type: 'button', class: `btn small ${cls}`, on: { click: async () => {
      const r = await api('PATCH', `/reviews/${v.id}`, { status });
      if (r.ok) { say(`Review ${status}.`, true); loadReviews(); } else say('Could not update the review.');
    } } }, label);
    return h('article', { class: 'item' }, h('div', { class: 'detail' },
      h('div', {}, h('span', { class: `badge ${v.status}` }, v.status), ` ${'★'.repeat(v.rating)}${'☆'.repeat(5 - v.rating)} · ${v.reviewer_name}${v.pet_name ? ` (owner of ${v.pet_name})` : ''} · ${when(v.created_at)}`),
      h('p', {}, v.content),
      h('div', { class: 'actions' },
        v.status !== 'approved' ? act('approved', 'Approve', 'good') : null,
        v.status !== 'rejected' ? act('rejected', 'Reject', 'danger') : null,
        v.status !== 'pending' ? act('pending', 'Move to pending', 'ghost') : null)));
  }

  // ---- start ----
  (async () => {
    try {
      const r = await api('GET', '/session');
      if (r.ok) { showApp(); loadEnquiries(); } else showLogin();
    } catch { /* showLogin already called on 401 */ }
  })();
})();
