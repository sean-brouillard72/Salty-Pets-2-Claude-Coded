-- Row Level Security + privileges. Deny by default, then grant the minimum.

alter table public.customers   enable row level security;
alter table public.enquiries   enable row level security;
alter table public.pets        enable row level security;
alter table public.reviews     enable row level security;
alter table public.admins      enable row level security;
alter table public.rate_limits enable row level security;

-- Supabase grants broad default privileges on new objects; remove them first.
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from anon, authenticated, public;

create function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.admins where user_id = (select auth.uid()));
$$;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

-- ADMIN: read, moderate, delete. Never insert.
grant select, delete on public.customers to authenticated;
grant select, delete on public.pets      to authenticated;
grant select, delete on public.enquiries to authenticated;
grant update (status) on public.enquiries to authenticated;
grant select, delete  on public.reviews   to authenticated;
grant update (status, moderated_at) on public.reviews to authenticated;

create policy admin_select on public.customers for select to authenticated using (public.is_admin());
create policy admin_delete on public.customers for delete to authenticated using (public.is_admin());
create policy admin_select on public.pets for select to authenticated using (public.is_admin());
create policy admin_delete on public.pets for delete to authenticated using (public.is_admin());
create policy admin_select on public.enquiries for select to authenticated using (public.is_admin());
create policy admin_update on public.enquiries for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy admin_delete on public.enquiries for delete to authenticated using (public.is_admin());
create policy admin_select on public.reviews for select to authenticated using (public.is_admin());
create policy admin_update on public.reviews for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy admin_delete on public.reviews for delete to authenticated using (public.is_admin());

-- PUBLIC (anon): ONLY approved reviews, ONLY safe columns. Nothing else is granted.
grant select (id, reviewer_name, pet_name, rating, content, status, created_at) on public.reviews to anon;
create policy public_read_approved on public.reviews for select to anon using (status = 'approved');

-- admins and rate_limits: RLS on, no policies, no grants => service role (server) only.
