-- Server-side-only functions: SECURITY DEFINER, executable ONLY by the service role.

create function public.submit_enquiry(p jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_customer uuid;
  v_enquiry  uuid;
  v_ref      text;
begin
  select e.reference into v_ref from public.enquiries e
   where e.submission_id = (p->>'submission_id')::uuid;
  if found then
    return jsonb_build_object('reference', v_ref, 'duplicate', true);
  end if;

  -- Repeat customers matched by normalised phone. Public input never overwrites
  -- existing details (an email is only filled in if missing).
  insert into public.customers (full_name, phone_e164, email)
  values (p->>'name', p->>'phone', nullif(p->>'email', ''))
  on conflict (phone_e164) do update
    set email = coalesce(public.customers.email, excluded.email)
  returning id into v_customer;

  insert into public.enquiries (
    submission_id, customer_id, service, start_date, end_date, preferred_time,
    visits_per_day, frequency, specific_times, notes, estimate_cents, estimate_breakdown)
  values (
    (p->>'submission_id')::uuid, v_customer, p->>'service',
    (p->>'start_date')::date, nullif(p->>'end_date', '')::date,
    p->>'preferred_time', nullif(p->>'visits_per_day', '')::smallint,
    p->>'frequency', nullif(p->>'specific_times', ''), nullif(p->>'notes', ''),
    nullif(p->>'estimate_cents', '')::integer, p->'estimate_breakdown')
  on conflict (submission_id) do nothing
  returning id, reference into v_enquiry, v_ref;

  if v_enquiry is null then
    select e.reference into v_ref from public.enquiries e
     where e.submission_id = (p->>'submission_id')::uuid;
    return jsonb_build_object('reference', v_ref, 'duplicate', true);
  end if;

  insert into public.pets (enquiry_id, position, animal_type, name, breed, age, notes)
  select v_enquiry, t.idx::smallint, t.elem->>'type', t.elem->>'name',
         nullif(t.elem->>'breed', ''), nullif(t.elem->>'age', ''), nullif(t.elem->>'notes', '')
  from jsonb_array_elements(p->'pets') with ordinality as t(elem, idx);

  return jsonb_build_object('reference', v_ref, 'duplicate', false);
end $$;

create function public.rate_limit_hit(p_key text, p_limit integer, p_window_seconds integer)
returns boolean language plpgsql security definer set search_path = '' as $$
declare v_hits integer;
begin
  insert into public.rate_limits as r (key, window_start, hits)
  values (p_key, now(), 1)
  on conflict (key) do update set
    window_start = case when r.window_start < now() - make_interval(secs => p_window_seconds)
                        then now() else r.window_start end,
    hits         = case when r.window_start < now() - make_interval(secs => p_window_seconds)
                        then 1 else r.hits + 1 end
  returning hits into v_hits;

  if random() < 0.02 then
    delete from public.rate_limits where window_start < now() - interval '1 day';
  end if;
  return v_hits <= p_limit;
end $$;

create function public.purge_old_enquiries(p_months integer default 24) returns integer
language plpgsql security definer set search_path = '' as $$
declare v_count integer;
begin
  with gone as (
    delete from public.enquiries
     where created_at < now() - make_interval(months => p_months)
       and status in ('declined','completed')
    returning 1)
  select count(*) into v_count from gone;
  return v_count;
end $$;

revoke all on function public.submit_enquiry(jsonb)                  from public, anon, authenticated;
revoke all on function public.rate_limit_hit(text, integer, integer) from public, anon, authenticated;
revoke all on function public.purge_old_enquiries(integer)           from public, anon, authenticated;
grant execute on function public.submit_enquiry(jsonb)                  to service_role;
grant execute on function public.rate_limit_hit(text, integer, integer) to service_role;
grant execute on function public.purge_old_enquiries(integer)           to service_role;
