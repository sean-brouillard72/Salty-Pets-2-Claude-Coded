-- Salty Paws: schema. Run migrations in order (0001, 0002, 0003).

create table public.customers (
  id          uuid primary key default gen_random_uuid(),
  full_name   text not null check (char_length(full_name) between 1 and 100),
  phone_e164  text not null unique check (phone_e164 ~ '^\+61[23478][0-9]{8}$'),
  email       text check (email is null or char_length(email) <= 254),
  created_at  timestamptz not null default now()
);

create table public.enquiries (
  id             uuid primary key default gen_random_uuid(),
  reference      text not null unique
                 default ('SP-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  submission_id  uuid not null unique,
  customer_id    uuid not null references public.customers(id) on delete cascade,
  service        text not null check (service in
                   ('meet_and_greet','dog_walk_30','dog_walk_60','home_visit','boarding','overnight','not_sure')),
  start_date     date not null,
  end_date       date,
  preferred_time text not null default 'flexible' check (preferred_time in
                   ('flexible','early_morning','morning','midday','afternoon','evening')),
  visits_per_day smallint check (visits_per_day between 1 and 3),
  frequency      text not null default 'not_sure' check (frequency in
                   ('one_off','weekly','several_weekly','not_sure')),
  specific_times text check (specific_times is null or char_length(specific_times) <= 300),
  notes          text check (notes is null or char_length(notes) <= 2000),
  status         text not null default 'new' check (status in
                   ('new','contacted','awaiting_response','accepted','declined','completed')),
  estimate_cents      integer check (estimate_cents is null or estimate_cents >= 0),
  estimate_breakdown  jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (end_date is null or end_date >= start_date)
);
create index enquiries_customer_idx on public.enquiries (customer_id);
create index enquiries_status_created_idx on public.enquiries (status, created_at desc);
create index enquiries_created_idx on public.enquiries (created_at desc);

create table public.pets (
  id          uuid primary key default gen_random_uuid(),
  enquiry_id  uuid not null references public.enquiries(id) on delete cascade,
  position    smallint not null default 1,
  animal_type text not null check (animal_type in
                ('dog','cat','bird','rabbit','guinea_pig','fish','reptile','other')),
  name        text not null check (char_length(name) between 1 and 60),
  breed       text check (breed is null or char_length(breed) <= 60),
  age         text check (age is null or char_length(age) <= 30),
  notes       text check (notes is null or char_length(notes) <= 500)
);
create index pets_enquiry_idx on public.pets (enquiry_id);

create table public.reviews (
  id              uuid primary key default gen_random_uuid(),
  submission_id   uuid not null unique,
  reviewer_name   text not null check (char_length(reviewer_name) between 1 and 60),
  pet_name        text check (pet_name is null or char_length(pet_name) <= 60),
  rating          smallint not null check (rating between 1 and 5),
  content         text not null check (char_length(content) between 10 and 1500),
  publish_consent boolean not null check (publish_consent = true),
  status          text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at      timestamptz not null default now(),
  moderated_at    timestamptz
);
create index reviews_status_created_idx on public.reviews (status, created_at desc);

-- The owner account(s) allowed to use the dashboard. Added manually (see README).
create table public.admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- Fixed-window counters for rate limiting (keys are HMAC hashes, never raw IPs).
create table public.rate_limits (
  key          text primary key,
  window_start timestamptz not null default now(),
  hits         integer not null default 1
);
create index rate_limits_window_idx on public.rate_limits (window_start);

create function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end $$;

create trigger enquiries_touch before update on public.enquiries
  for each row execute function public.touch_updated_at();

-- Deleting a customer's last enquiry also deletes the customer (no orphaned personal info).
create function public.delete_orphan_customer() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  delete from public.customers c
  where c.id = old.customer_id
    and not exists (select 1 from public.enquiries e where e.customer_id = c.id);
  return null;
end $$;

create trigger enquiries_orphan_cleanup after delete on public.enquiries
  for each row execute function public.delete_orphan_customer();
