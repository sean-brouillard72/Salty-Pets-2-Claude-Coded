-- RLS / privilege tests. Run ONCE in the Supabase SQL editor AFTER applying migrations 0001-0003.
-- Everything runs inside a transaction that is ROLLED BACK, so no data is left behind.
-- Read the "Messages"/NOTICE output: every line should start with PASS. Any FAIL = do not go live.
-- (Written for Supabase Postgres. NOT executed by the author of this repo: no Postgres in the build sandbox.)

begin;

-- ---- fixtures (as postgres) ----
insert into auth.users (id, email) values
  ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', 'test-admin@example.invalid'),
  ('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb', 'test-stranger@example.invalid');
insert into public.admins (user_id) values ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');

select public.submit_enquiry(jsonb_build_object(
  'submission_id', 'cccccccc-cccc-4ccc-8ccc-cccccccccccc', 'name', 'Test Person', 'phone', '+61412345678', 'email', '',
  'service', 'dog_walk_30', 'start_date', (current_date + 7)::text, 'end_date', '', 'preferred_time', 'flexible',
  'visits_per_day', '1', 'frequency', 'one_off', 'specific_times', '', 'notes', 'secret note',
  'pets', jsonb_build_array(jsonb_build_object('type','dog','name','Rex'))));

insert into public.reviews (submission_id, reviewer_name, rating, content, publish_consent, status) values
  ('dddddddd-dddd-4ddd-8ddd-dddddddddddd', 'Pending Pat',  5, 'pending review text here',  true, 'pending'),
  ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee', 'Approved Alex', 5, 'approved review text here', true, 'approved');

-- ---- 1. ANON must be denied everywhere except approved reviews' safe columns ----
do $$
declare t record; n int;
begin
  set local role anon;
  for t in select * from (values
    ('read customers',          'select 1 from public.customers'),
    ('read enquiries',          'select 1 from public.enquiries'),
    ('read pets',               'select 1 from public.pets'),
    ('read admins',             'select 1 from public.admins'),
    ('read rate_limits',        'select 1 from public.rate_limits'),
    ('read review consent col', 'select publish_consent from public.reviews'),
    ('read review submission_id','select submission_id from public.reviews'),
    ('insert customers',        $q$insert into public.customers (full_name, phone_e164) values ('x','+61400000000')$q$),
    ('insert enquiries',        $q$insert into public.enquiries (submission_id, customer_id, service, start_date) values (gen_random_uuid(), gen_random_uuid(), 'dog_walk_30', current_date)$q$),
    ('insert reviews',          $q$insert into public.reviews (submission_id, reviewer_name, rating, content, publish_consent) values (gen_random_uuid(),'x',5,'abcdefghijk',true)$q$),
    ('approve a review',        $q$update public.reviews set status = 'approved'$q$),
    ('delete reviews',          'delete from public.reviews'),
    ('update enquiries',        $q$update public.enquiries set status = 'declined'$q$),
    ('delete enquiries',        'delete from public.enquiries'),
    ('call submit_enquiry',     $q$select public.submit_enquiry('{}'::jsonb)$q$),
    ('call rate_limit_hit',     $q$select public.rate_limit_hit('k', 1, 1)$q$),
    ('call purge_old_enquiries','select public.purge_old_enquiries(1)'),
    ('call is_admin',           'select public.is_admin()')
  ) v(label, stmt) loop
    begin
      execute t.stmt;
      raise notice 'FAIL  anon was allowed to: %', t.label;
    exception when insufficient_privilege then
      raise notice 'PASS  anon denied: %', t.label;
    end;
  end loop;

  select count(*) into n from public.reviews;          -- allowed columns only, RLS filters rows
  if n = 1 then raise notice 'PASS  anon sees exactly the 1 approved review (pending hidden)';
  else raise notice 'FAIL  anon sees % reviews (expected 1)', n; end if;
  reset role;
end $$;

-- ---- 2. A signed-in user who is NOT an admin sees and changes nothing ----
do $$
declare t record; n int;
begin
  set local role authenticated;
  perform set_config('request.jwt.claims', '{"sub":"bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb","role":"authenticated"}', true);

  if public.is_admin() then raise notice 'FAIL  stranger counted as admin'; else raise notice 'PASS  stranger is not admin'; end if;
  for t in select * from (values
    ('customers', 'select 1 from public.customers'), ('enquiries', 'select 1 from public.enquiries'),
    ('pets', 'select 1 from public.pets'), ('reviews', 'select 1 from public.reviews')) v(label, stmt) loop
    execute 'select count(*) from (' || t.stmt || ') s' into n;
    if n = 0 then raise notice 'PASS  stranger sees 0 rows of %', t.label; else raise notice 'FAIL  stranger sees % rows of %', n, t.label; end if;
  end loop;
  for t in select * from (values
    ('update enquiries', $q$update public.enquiries set status = 'declined'$q$),
    ('delete enquiries', 'delete from public.enquiries'), ('delete customers', 'delete from public.customers'),
    ('approve reviews',  $q$update public.reviews set status = 'approved'$q$), ('delete reviews', 'delete from public.reviews')) v(label, stmt) loop
    execute t.stmt; get diagnostics n = row_count;
    if n = 0 then raise notice 'PASS  stranger changed 0 rows: %', t.label; else raise notice 'FAIL  stranger changed % rows: %', n, t.label; end if;
  end loop;
  begin
    execute $q$select * from public.admins$q$; raise notice 'FAIL  stranger can read admins';
  exception when insufficient_privilege then raise notice 'PASS  stranger cannot read admins'; end;
  reset role;
end $$;

-- ---- 3. The admin can read, moderate and delete; but only the intended columns, and never insert ----
do $$
declare n int;
begin
  set local role authenticated;
  perform set_config('request.jwt.claims', '{"sub":"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa","role":"authenticated"}', true);

  if public.is_admin() then raise notice 'PASS  admin recognised'; else raise notice 'FAIL  admin not recognised'; end if;
  select count(*) into n from public.enquiries;  if n = 1 then raise notice 'PASS  admin reads enquiries'; else raise notice 'FAIL  admin sees % enquiries', n; end if;
  select count(*) into n from public.pets;       if n = 1 then raise notice 'PASS  admin reads pets';      else raise notice 'FAIL  admin sees % pets', n; end if;
  select count(*) into n from public.reviews;    if n = 2 then raise notice 'PASS  admin reads all reviews'; else raise notice 'FAIL  admin sees % reviews', n; end if;

  update public.enquiries set status = 'contacted'; get diagnostics n = row_count;
  if n = 1 then raise notice 'PASS  admin can update enquiry status'; else raise notice 'FAIL  admin update affected % rows', n; end if;
  update public.reviews set status = 'approved', moderated_at = now() where reviewer_name = 'Pending Pat'; get diagnostics n = row_count;
  if n = 1 then raise notice 'PASS  admin can moderate a review'; else raise notice 'FAIL  admin moderation affected % rows', n; end if;

  begin
    update public.enquiries set notes = 'tampered'; raise notice 'FAIL  admin could edit non-status columns';
  exception when insufficient_privilege then raise notice 'PASS  admin cannot edit other enquiry columns'; end;
  begin
    insert into public.customers (full_name, phone_e164) values ('x', '+61400000000'); raise notice 'FAIL  admin could insert customers';
  exception when insufficient_privilege then raise notice 'PASS  admin cannot insert customers directly'; end;

  delete from public.enquiries; get diagnostics n = row_count;
  if n = 1 then raise notice 'PASS  admin can delete an enquiry'; else raise notice 'FAIL  admin delete affected % rows', n; end if;
  select count(*) into n from public.customers;
  if n = 0 then raise notice 'PASS  orphaned customer removed with their last enquiry'; else raise notice 'FAIL  % orphan customers remain', n; end if;
  reset role;
end $$;

-- ---- 4. Server-side functions (service role) ----
do $$
declare r jsonb; a boolean; b boolean; c boolean; s uuid := gen_random_uuid();
begin
  set local role service_role;
  r := public.submit_enquiry(jsonb_build_object('submission_id', s, 'name', 'Dup Test', 'phone', '+61498765432', 'email', '',
    'service', 'meet_and_greet', 'start_date', (current_date + 3)::text, 'end_date', '', 'preferred_time', 'flexible',
    'visits_per_day', '', 'frequency', 'not_sure', 'specific_times', '', 'notes', '',
    'pets', jsonb_build_array(jsonb_build_object('type','cat','name','Tom'))));
  if (r->>'duplicate')::boolean is false then raise notice 'PASS  service role can submit an enquiry'; else raise notice 'FAIL  first submit flagged duplicate'; end if;
  r := public.submit_enquiry(jsonb_build_object('submission_id', s, 'name', 'Dup Test', 'phone', '+61498765432', 'email', '',
    'service', 'meet_and_greet', 'start_date', (current_date + 3)::text, 'end_date', '', 'preferred_time', 'flexible',
    'visits_per_day', '', 'frequency', 'not_sure', 'specific_times', '', 'notes', '',
    'pets', jsonb_build_array(jsonb_build_object('type','cat','name','Tom'))));
  if (r->>'duplicate')::boolean then raise notice 'PASS  duplicate submission detected'; else raise notice 'FAIL  duplicate not detected'; end if;
  a := public.rate_limit_hit('test-key', 2, 60); b := public.rate_limit_hit('test-key', 2, 60); c := public.rate_limit_hit('test-key', 2, 60);
  if a and b and not c then raise notice 'PASS  rate limiter allows 2 then blocks'; else raise notice 'FAIL  rate limiter: % % %', a, b, c; end if;
  reset role;
end $$;

rollback;
