import { json, readJson, sameOrigin, clientIp, hashIp, fakeReference, isObj } from '../../src/lib/http.mjs';
import { validateEnquiry } from '../../src/lib/validate.mjs';
import { estimate } from '../../src/lib/pricing.mjs';
import { verifyTurnstile } from '../../src/lib/turnstile.mjs';
import { allow } from '../../src/lib/ratelimit.mjs';
import { rpc } from '../../src/lib/supabase.mjs';
import { notifyNewEnquiry } from '../../src/lib/email.mjs';
import { log, errReason } from '../../src/lib/log.mjs';
import { LIMITS, SERVICES } from '../../src/config/business.mjs';

export const config = { path: '/api/enquiry' };
const ROUTE = 'enquiry';

export default async (req, context) => {
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' }, { headers: { Allow: 'POST' } });
  if (!sameOrigin(req)) { log('rejected', { route: ROUTE, reason: 'origin' }); return json(403, { error: 'forbidden' }); }

  try {
    const rawIp = clientIp(req, context);
    const ip = hashIp(rawIp);

    const parsed = await readJson(req, LIMITS.maxBodyBytes);
    if (!parsed.ok) return json(parsed.status, { error: parsed.error });
    const body = parsed.value;

    // Honeypot: real people never see/fill this field. Pretend success, store nothing.
    if (isObj(body) && typeof body.website === 'string' && body.website.trim() !== '') {
      log('honeypot', { route: ROUTE, ip });
      return json(200, { ok: true, reference: fakeReference(), duplicate: false, estimate: null });
    }

    if (!(await allow(ip, ROUTE, 8, 900))) {
      log('rate_limited', { route: ROUTE, ip });
      return json(429, { error: 'rate_limited' }, { headers: { 'Retry-After': '900' } });
    }

    const v = validateEnquiry(body);
    if (!v.ok) return json(400, { error: v.code, fields: v.errors });
    const d = v.value;

    if (!(await verifyTurnstile(d.turnstile_token, rawIp))) {
      log('captcha_failed', { route: ROUTE, ip });
      return json(400, { error: 'captcha' });
    }

    const est = estimate(d); // trusted, server-side
    const r = await rpc('submit_enquiry', {
      p: {
        submission_id: d.submission_id, name: d.name, phone: d.phone, email: d.email, pets: d.pets,
        service: d.service, start_date: d.start_date, end_date: d.end_date, preferred_time: d.preferred_time,
        visits_per_day: d.visits_per_day, frequency: d.frequency, specific_times: d.specific_times, notes: d.notes,
        estimate_cents: est ? est.totalCents : null, estimate_breakdown: est ? est.breakdown : null,
      },
    });
    if (!r.ok || !r.data || typeof r.data.reference !== 'string') {
      log('db_error', { route: ROUTE, status: r.status });
      return json(500, { error: 'server_error' });
    }

    if (!r.data.duplicate) {
      const mail = await notifyNewEnquiry({
        reference: r.data.reference, name: d.name, serviceLabel: SERVICES[d.service], startDate: d.start_date,
      });
      if (!mail.sent) log('email_failed', { route: ROUTE, reason: mail.reason });
    }

    return json(200, {
      ok: true,
      reference: r.data.reference,
      duplicate: r.data.duplicate === true,
      estimate: est ? {
        totalCents: est.totalCents,
        free: est.breakdown.free === true,
        holidaySurcharge: (est.breakdown.holidaySurchargeCents || 0) > 0,
      } : null,
    });
  } catch (e) {
    log('error', { route: ROUTE, reason: errReason(e) });
    return json(500, { error: 'server_error' });
  }
};
