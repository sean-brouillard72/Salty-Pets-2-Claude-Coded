import { json, readJson, sameOrigin, clientIp, hashIp, isObj } from '../../src/lib/http.mjs';
import { request, asUser, asAnon } from '../../src/lib/supabase.mjs';
import { requireEnv } from '../../src/lib/http.mjs';
import { allow } from '../../src/lib/ratelimit.mjs';
import { isUuid } from '../../src/lib/validate.mjs';
import { STATUSES, REVIEW_STATUSES } from '../../src/config/business.mjs';
import { log, errReason } from '../../src/lib/log.mjs';

export const config = { path: '/api/admin/*' };
const ROUTE = 'admin';
const AT = 'sp_at';
const RT = 'sp_rt';

const cookie = (name, value, maxAge) =>
  `${name}=${value}; Path=/api/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
const sessionCookies = (s) => [cookie(AT, s.access_token, Math.min(s.expires_in || 3600, 3600)), cookie(RT, s.refresh_token, 60 * 60 * 24 * 7)];
const clearCookies = () => [cookie(AT, '', 0), cookie(RT, '', 0)];

function readCookies(req) {
  const out = {};
  for (const part of (req.headers.get('cookie') || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

// Verifies the session server-side with Supabase Auth AND that the user is an admin.
async function authenticate(req) {
  const c = readCookies(req);
  let token = null;
  let cookies = [];
  if (c[AT]) {
    const u = await request('/auth/v1/user', { key: requireEnv('SUPABASE_ANON_KEY'), bearer: c[AT] });
    if (u.ok) token = c[AT];
  }
  if (!token && c[RT]) {
    const r = await asAnon('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: c[RT] } });
    if (r.ok && r.data?.access_token && r.data?.refresh_token) { token = r.data.access_token; cookies = sessionCookies(r.data); }
  }
  if (!token) return null;
  const a = await asUser(token, '/rest/v1/rpc/is_admin', { method: 'POST', body: {} });
  if (!a.ok || a.data !== true) return null;
  return { token, cookies };
}

const unauthorised = () => json(401, { error: 'unauthorised' }, { cookies: clearCookies() });
const notFound = () => json(404, { error: 'not_found' });

export default async (req, context) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/admin/, '').replace(/\/+$/, '') || '/';
  const method = req.method;
  const parts = path.split('/').filter(Boolean);

  if (method !== 'GET') {
    // CSRF: same-origin + custom header (cannot be sent cross-site without CORS) + SameSite=Strict cookies.
    if (!sameOrigin(req) || req.headers.get('x-requested-with') !== 'salty-paws') {
      log('rejected', { route: ROUTE, reason: 'csrf' });
      return json(403, { error: 'forbidden' });
    }
  }

  try {
    // ---- login ----
    if (method === 'POST' && path === '/login') {
      const ip = hashIp(clientIp(req, context));
      if (!(await allow(ip, 'admin_login', 10, 900))) {
        log('rate_limited', { route: ROUTE, ip });
        return json(429, { error: 'rate_limited' }, { headers: { 'Retry-After': '900' } });
      }
      const p = await readJson(req, 2048);
      if (!p.ok) return json(p.status, { error: p.error });
      const b = p.value;
      if (!isObj(b) || typeof b.email !== 'string' || typeof b.password !== 'string' ||
          b.email.length > 254 || b.password.length > 200 || !b.email || !b.password) {
        return json(400, { error: 'invalid_credentials' });
      }
      const r = await asAnon('/auth/v1/token?grant_type=password', { method: 'POST', body: { email: b.email.trim(), password: b.password } });
      if (!r.ok || !r.data?.access_token) { log('login_failed', { route: ROUTE, ip }); return json(401, { error: 'invalid_credentials' }); }
      const a = await asUser(r.data.access_token, '/rest/v1/rpc/is_admin', { method: 'POST', body: {} });
      if (!a.ok || a.data !== true) {
        await asUser(r.data.access_token, '/auth/v1/logout?scope=local', { method: 'POST' }).catch(() => {});
        log('login_not_admin', { route: ROUTE, ip });
        return json(401, { error: 'invalid_credentials' }); // same response: no account enumeration
      }
      return json(200, { ok: true }, { cookies: sessionCookies(r.data) });
    }

    // ---- logout (always clears cookies; revokes the refresh token server-side if possible) ----
    if (method === 'POST' && path === '/logout') {
      const c = readCookies(req);
      if (c[AT]) await asUser(c[AT], '/auth/v1/logout?scope=local', { method: 'POST' }).catch(() => {});
      return json(200, { ok: true }, { cookies: clearCookies() });
    }

    // Everything below needs an authenticated admin.
    const auth = await authenticate(req);
    if (!auth) return unauthorised();
    const { token } = auth;
    const done = (status, body) => json(status, body, { cookies: auth.cookies });

    if (method === 'GET' && path === '/session') return done(200, { ok: true });

    if (method === 'GET' && path === '/enquiries') {
      const status = url.searchParams.get('status');
      if (status && !STATUSES.includes(status)) return done(400, { error: 'invalid_status' });
      const q = '/rest/v1/enquiries?select=*,customers(full_name,phone_e164,email),pets(id,position,animal_type,name,breed,age,notes)' +
        `&order=created_at.desc&limit=200${status ? `&status=eq.${status}` : ''}`;
      const r = await asUser(token, q);
      if (!r.ok) { log('db_error', { route: ROUTE, status: r.status }); return done(r.status === 401 ? 401 : 500, { error: 'server_error' }); }
      return done(200, { enquiries: r.data });
    }

    if (method === 'GET' && path === '/reviews') {
      const status = url.searchParams.get('status') || 'pending';
      if (!REVIEW_STATUSES.includes(status)) return done(400, { error: 'invalid_status' });
      const r = await asUser(token, `/rest/v1/reviews?select=*&status=eq.${status}&order=created_at.desc&limit=200`);
      if (!r.ok) { log('db_error', { route: ROUTE, status: r.status }); return done(500, { error: 'server_error' }); }
      return done(200, { reviews: r.data });
    }

    // /enquiries/:id, /reviews/:id, /customers/:id
    if (parts.length === 2 && ['enquiries', 'reviews', 'customers'].includes(parts[0])) {
      const [kind, id] = parts;
      if (!isUuid(id)) return done(400, { error: 'invalid_id' });
      const target = `/rest/v1/${kind}?id=eq.${id}`;
      const ret = { Prefer: 'return=representation' };

      if (method === 'PATCH' && (kind === 'enquiries' || kind === 'reviews')) {
        const p = await readJson(req, 512);
        if (!p.ok) return done(p.status, { error: p.error });
        const allowed = kind === 'enquiries' ? STATUSES : REVIEW_STATUSES;
        if (!isObj(p.value) || Object.keys(p.value).join() !== 'status' || !allowed.includes(p.value.status)) {
          return done(400, { error: 'invalid_status' });
        }
        const patch = kind === 'reviews' ? { status: p.value.status, moderated_at: new Date().toISOString() } : { status: p.value.status };
        const r = await asUser(token, target, { method: 'PATCH', headers: ret, body: patch });
        if (!r.ok) { log('db_error', { route: ROUTE, status: r.status }); return done(500, { error: 'server_error' }); }
        return Array.isArray(r.data) && r.data.length === 1 ? done(200, { ok: true }) : notFound();
      }

      if (method === 'DELETE' && (kind === 'enquiries' || kind === 'customers')) {
        const r = await asUser(token, target, { method: 'DELETE', headers: ret });
        if (!r.ok) { log('db_error', { route: ROUTE, status: r.status }); return done(500, { error: 'server_error' }); }
        return Array.isArray(r.data) && r.data.length === 1 ? done(200, { ok: true }) : notFound();
      }
    }
    return notFound();
  } catch (e) {
    log('error', { route: ROUTE, reason: errReason(e) });
    return json(500, { error: 'server_error' });
  }
};
