import { json } from '../../src/lib/http.mjs';
import { PRICES, HOLIDAY_SURCHARGE } from '../../src/config/business.mjs';

export const config = { path: '/api/config' };

// Public, non-secret settings for the browser (Turnstile SITE key + display prices).
export default async (req) => {
  if (req.method !== 'GET') return json(405, { error: 'method_not_allowed' }, { headers: { Allow: 'GET' } });
  return json(200, {
    turnstileSiteKey: process.env.TURNSTILE_SITE_KEY || '',
    prices: PRICES,
    holidaySurchargePercent: Math.round(HOLIDAY_SURCHARGE * 100),
  }, { headers: { 'Cache-Control': 'public, max-age=300' } });
};
