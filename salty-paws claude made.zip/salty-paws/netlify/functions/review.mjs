import { json, readJson, sameOrigin, clientIp, hashIp, isObj } from '../../src/lib/http.mjs';
import { validateReview } from '../../src/lib/validate.mjs';
import { verifyTurnstile } from '../../src/lib/turnstile.mjs';
import { allow } from '../../src/lib/ratelimit.mjs';
import { asService } from '../../src/lib/supabase.mjs';
import { log, errReason } from '../../src/lib/log.mjs';

export const config = { path: '/api/review' };
const ROUTE = 'review';

export default async (req, context) => {
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' }, { headers: { Allow: 'POST' } });
  if (!sameOrigin(req)) { log('rejected', { route: ROUTE, reason: 'origin' }); return json(403, { error: 'forbidden' }); }

  try {
    const rawIp = clientIp(req, context);
    const ip = hashIp(rawIp);
    const parsed = await readJson(req, 8 * 1024);
    if (!parsed.ok) return json(parsed.status, { error: parsed.error });
    const body = parsed.value;

    if (isObj(body) && typeof body.website === 'string' && body.website.trim() !== '') {
      log('honeypot', { route: ROUTE, ip });
      return json(200, { ok: true });
    }
    if (!(await allow(ip, ROUTE, 3, 3600))) {
      log('rate_limited', { route: ROUTE, ip });
      return json(429, { error: 'rate_limited' }, { headers: { 'Retry-After': '3600' } });
    }
    const v = validateReview(body);
    if (!v.ok) return json(400, { error: v.code, fields: v.errors });
    const d = v.value;
    if (!(await verifyTurnstile(d.turnstile_token, rawIp))) {
      log('captcha_failed', { route: ROUTE, ip });
      return json(400, { error: 'captcha' });
    }

    // Always inserted as 'pending' (column default). Duplicate submission_ids are ignored.
    const r = await asService('/rest/v1/reviews?on_conflict=submission_id', {
      method: 'POST',
      headers: { Prefer: 'resolution=ignore-duplicates,return=minimal' },
      body: {
        submission_id: d.submission_id, reviewer_name: d.name, pet_name: d.pet_name || null,
        rating: d.rating, content: d.content, publish_consent: true,
      },
    });
    if (!r.ok) { log('db_error', { route: ROUTE, status: r.status }); return json(500, { error: 'server_error' }); }
    return json(200, { ok: true });
  } catch (e) {
    log('error', { route: ROUTE, reason: errReason(e) });
    return json(500, { error: 'server_error' });
  }
};
