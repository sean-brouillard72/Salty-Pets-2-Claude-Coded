import { json } from '../../src/lib/http.mjs';
import { asAnon } from '../../src/lib/supabase.mjs';
import { log, errReason } from '../../src/lib/log.mjs';

export const config = { path: '/api/reviews' };

// Public list of APPROVED reviews. Uses the public key, so the database itself (RLS +
// column grants) guarantees nothing else can be read, even if this code were wrong.
export default async (req) => {
  if (req.method !== 'GET') return json(405, { error: 'method_not_allowed' }, { headers: { Allow: 'GET' } });
  try {
    const r = await asAnon('/rest/v1/reviews?select=reviewer_name,pet_name,rating,content,created_at&status=eq.approved&order=created_at.desc&limit=50');
    if (!r.ok || !Array.isArray(r.data)) { log('db_error', { route: 'reviews', status: r.status }); return json(500, { error: 'server_error' }); }
    return json(200, { reviews: r.data }, { headers: { 'Cache-Control': 'public, max-age=60' } });
  } catch (e) {
    log('error', { route: 'reviews', reason: errReason(e) });
    return json(500, { error: 'server_error' });
  }
};
