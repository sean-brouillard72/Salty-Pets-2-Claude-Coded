import { asAnon } from '../../src/lib/supabase.mjs';
import { log, errReason } from '../../src/lib/log.mjs';

// Scheduled (not publicly routable): makes a tiny read-only query a few times a day so a
// Supabase FREE project doesn't get auto-paused for inactivity. Uses the public key + RLS.
export const config = { schedule: '0 */8 * * *' };

export default async () => {
  try {
    const r = await asAnon('/rest/v1/reviews?select=id&limit=1');
    log(r.ok ? 'keepalive_ok' : 'keepalive_failed', { route: 'keepalive', status: r.status });
  } catch (e) {
    log('keepalive_failed', { route: 'keepalive', reason: errReason(e) });
  }
};
